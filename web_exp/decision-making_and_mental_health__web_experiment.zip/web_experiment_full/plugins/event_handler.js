// Simple JS to prevent reloads and going back

window.onbeforeunload = function() {
  return '';
};
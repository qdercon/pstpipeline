/*
* Digit span task
*/

let digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]  //possible digits participants can get

let demo_start = 3    
let starting_trial = 1

let demo_sequence = jsPsych.randomization.sampleWithoutReplacement(digits, demo_start)  //chooses random digits
let sequence = jsPsych.randomization.sampleWithoutReplacement(digits, starting_trial)  //chooses random digits

let demo_id = -1
let seq_id = -1

/* create timeline array */
let timeline = [];

let instructions = {
    type: 'instructions',
    pages: ["<div style='font-size:1.5em'><p>This part of the experiment aims to assess your working memory.</p></div>",
            "<div style='font-size:1.25em'>"+
                "<p>During the task, you will see a short cross to focus your attention, and then a sequence of numbers, presented one at a time.</p>" + 
                "<p>Subsequently, a number pad will appear on the screen - simply click the numbers in the <em>same order</em> you saw them, and then press <em>Submit</em>.</p>" +
                "<div style='width: 100%; display: flex; justify-content: center;  flex-direction: row;'>"+
                    "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/fixation_instr.png'></img>" +
                    "<p class='small'><strong>Fixation cross</strong></p></div>" +
                    "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/digit_span_pic.png'></img>" +
                    "<p class='small'><strong>Number pad</strong></p></div>"+
                "</div>"+
            "</div>",
            "<div style='font-size:1.25em'><p>After you have submitted your answer, you will then receive feeback.</p>"+
            "<div style='width: 100%; display: flex; justify-content: center;  flex-direction: row;'>"+
                "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/correct_digit.png'></img></div>"+
                "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/incorrect_digit.png'></img></div>"+
            "</div>"+
            "<p>If you get the sequence correct, the next trial will include one extra digit. If you get it incorrect, you will have one more attempt at that sequence length.</p>"+
            "<p>The task will end when you get two sequences of the same length wrong in a row.</p>"+
            "</div>",
            "<div style='font-size:1.25em'>"+
                "<p>The task will begin with a demo trial (3-number sequence). You will then receive a prompt to proceed to the main test.</p>"+
                "<p>Press <strong>Next</strong> once you have read all the instructions, and are ready to begin the practice trial.</p>"+
            "</div>"
    ],
    show_clickable_nav: true,
    allow_keys: false,
    show_page_number: true,
    button_label_previous: 'Prev'
};
timeline.push(instructions);

let fixation = {
    type: 'html-keyboard-response',
    stimulus: '<div class="fade-in1" style="font-size:5em;">+</div>',
    choices: jsPsych.NO_KEYS,
    trial_duration: 1500,
    data: { test_part: 'fixation' }
}

let demo_stimuli = {
    type: 'html-keyboard-response',
    stimulus: function(){
        demo_id+=1
        return '<div class="fade-in2" style="font-size:4.5em;">'+demo_sequence[demo_id]+'</div>'
    },
    choices: jsPsych.NO_KEYS,
    trial_duration: 1000,
    on_finish: function(){
        if (demo_id + 1 >=demo_sequence.length){
        jsPsych.endCurrentTimeline()
        }
    }
}

let demo_recall = {
    type: 'digit-span-recall',
    correct_order: function(){
        return demo_sequence
        },
    trial_duration: null,
    on_finish: function(){
        let acc = jsPsych.data.get().last(1).values()[0].accuracy;
        if (acc==1){
            demo_start += 1
        }
        // this code prevents immediate repetition of digits where digit span >= 8            
        demo_sequence = jsPsych.randomization.sampleWithoutReplacement(digits, demo_start)
        demo_id = -1
    }
}

let demo_feedback = {
    type: 'html-keyboard-response',
    data: {test_part: 'feedback'},
    stimulus: function(){
        let accuracy = jsPsych.data.get().last(1).values()[0].accuracy;
        if(accuracy==1) {
            return '<p><div style="font-size:3em;color:#9462e9">Correct!</div></p>';
        } else {
            return '<p><div style="font-size:3em;color:#ff6663">Incorrect.</div></p>';
        }
    },
    choices: jsPsych.NO_KEYS,
    trial_duration: 1000
}
    
let test_stimuli = {
    type: 'html-keyboard-response',
    stimulus: function(){
        seq_id+=1
        return '<div class="fade-in2" style="font-size:4.5em;">'+sequence[seq_id]+'</div>'
    },
    choices: jsPsych.NO_KEYS,
    trial_duration: 1000,
    on_finish: function(){
        if (seq_id + 1 >=sequence.length){
        jsPsych.endCurrentTimeline()
        }
    }
}

let recall = {
    type: 'digit-span-recall',
    correct_order: function(){
        return sequence
        },
    trial_duration: null,
    on_finish: function(){
        let acc = jsPsych.data.get().last(1).values()[0].accuracy;
        if (acc==1){ starting_trial += 1 }

        // this code prevents immediate repetition of digits where digit span >= 9

        if (starting_trial<=9){ 
            sequence = jsPsych.randomization.sampleWithoutReplacement(digits, starting_trial);
        } else if (starting_trial<=17) {
            sequence = jsPsych.randomization.sampleWithoutReplacement(digits, 9);
            let extra = starting_trial-9;
            let id = digits.indexOf(sequence[8]);
            digits.splice(id, 1);
            let extraNumbers = jsPsych.randomization.sampleWithoutReplacement(digits, extra);
            sequence = sequence.concat(extraNumbers);
            digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
        } else {
            sequence = jsPsych.randomization.sampleWithoutReplacement(digits, 9);
            let id1 = digits.indexOf(sequence[8]);
            digits.splice(id1, 1);
            let extraNumbers1= jsPsych.randomization.sampleWithoutReplacement(digits, 8);
            sequence = sequence.concat(extraNumbers1);
            digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
            let extra = starting_trial-17;
            let id2 = digits.indexOf(sequence[16]);
            digits.splice(id2, 1);
            let extraNumbers2 = jsPsych.randomization.sampleWithoutReplacement(digits, extra);
            sequence = sequence.concat(extraNumbers2);
            digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
        }

        seq_id = -1;
    }
}


let feedback = {
    type: 'html-keyboard-response',
    data: {test_part: 'feedback'},
    stimulus: function(){
        let accuracy = jsPsych.data.get().last(1).values()[0].accuracy;
        if(accuracy==1) {
            return '<p><div style="font-size:3em;color:#9462e9">Correct!</div></p>';
        } else {
            return '<p><div style="font-size:3em;color:#ff6663">Incorrect.</div></p>';
        }
    },
    choices: jsPsych.NO_KEYS,
    trial_duration: 1000,
    on_finish: function(data) {
        let index = jsPsych.data.get().last(1).values()[0].trial_index;
        let accuracy = jsPsych.data.get().last(2).values()[0].accuracy;
        let curr_seq = jsPsych.data.get().last(2).values()[0].stimuli;
        let prev_trial_correct = jsPsych.data.get().filter({test_part: 'feedback'}).last(2).values()[0].correct;

        if (accuracy==1) {
            data.correct = true;
            data.digit_span = curr_seq.length;
            if (curr_seq.length==25) {
                data.final_digit_span = curr_seq.length;
            }
        } else if (prev_trial_correct || index==12) { // so you don't lose if you get the last practice and first test wrong
            data.correct = false;
            data.digit_span = curr_seq.length-1; // i.e. they only got the last one right
        } else {
            data.correct = false;
            data.digit_span = curr_seq.length-1;
            data.final_digit_span = curr_seq.length-1;
        }
    }
}

let test_end = {
    conditional_function: function() {
        let index = jsPsych.data.get().last(1).values()[0].trial_index;
        let penul_trial_correct = jsPsych.data.get().filter({test_part: 'feedback'}).last(2).values()[0].correct;
        let last_trial_correct = jsPsych.data.get().filter({test_part: 'feedback'}).last(1).values()[0].correct;
        let last_trial_span = jsPsych.data.get().last(1).values()[0].digit_span;
        if (!penul_trial_correct && !last_trial_correct && index>=16) {
          return true
        } else if (last_trial_span==25) {
            return true
        } else {
            return false
          }
        },
      timeline: [
        {
          type: 'html-keyboard-response',
          stimulus: function() {
            let dig_span = jsPsych.data.get().last(1).values()[0].final_digit_span
            return '<h2><p style="font-size:2em;color:#9ec1cf;line-height:1.25">You have completed the task.</p></h2>'+
                    '<p style="font-size:1.75em">Your maximum number of digits recalled correctly was <span style="color:#ff6663"><strong>'+dig_span+'</strong></span>. '+
                    'Please press any key to proceed to the questionnaires.</p>'                 
                },
          choices: jsPsych.ALL_KEYS,
          on_finish: function() {
            jsPsych.endExperiment()
          }
        }
      ]
    }

let practice_init = {
    type: 'html-keyboard-response',
    stimulus: '<div style="font-size:2em;line-height:1">Get ready! Press any key when you are ready to begin the practice trial.</div>'
};

let test_init = {
    type: 'html-keyboard-response',
    stimulus: '<div style="font-size:2em;line-height:1.25;color:#6B6D8C">Well done! You have completed the practice trial. Press any key when you are ready to begin the main test.</div>'
};

let practice_stack = {
    timeline: [demo_stimuli],
    repetitions: 3
}

let test_stack = {
    timeline: [test_stimuli],
    repetitions: 25
}

let demo_procedure = {
    timeline: [fixation, practice_stack, demo_recall, demo_feedback],
    repetitions: 1
}

let test_procedure = {
    timeline: [fixation, test_stack, recall, feedback, test_end],
    repetitions: 51
}

timeline.push(practice_init, demo_procedure, test_init, test_procedure)


/* start the experiment */
/* 
jatos.onLoad(function () {
  jsPsych.init({
    timeline: timeline,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, jatos.startNextComponent); 
    }
  });
});
*/


jatos.onLoad(function () {
  prolific_id = jatos.urlQueryParameters.PROLIFIC_PID;
  study_id = jatos.urlQueryParameters.STUDY_ID;
  session_id = jatos.urlQueryParameters.SESSION_ID;
  jsPsych.data.addProperties({prolific_id: prolific_id, study_id: study_id, session_id: session_id});
  jsPsych.init({
    timeline: timeline,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, jatos.startNextComponent); 
    }
  });
});
/*
* Main task - based on Frank et al. PNAS (2007)
*/

/* function to shuffle glyphs (Fisher-Yates Shuffle) */
function shuffle(array) {
  let currentIndex = array.length, temporaryValue, randomIndex;

  // while there remain elements to shuffle...
  while (0 !== currentIndex) {

      // pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // and swap it with the current element.
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
  }
  return array;
}

/* shuffle characters */

let a = "ま";
let b = "み";
let c = "そ";
let d = "の";
let e = "ら";
let f = "や";

let glyphs = shuffle([a, b, c, d, e, f])

/* create timeline array */
let timeline = [];

/* instructions */
let instructions = {
  type: 'instructions',
  pages: ["<div style='font-size:1.5em;max-width:1440px;line-height:1.5'>"+
            "<p>Please read the instructions on the following pages carefully, as you will be required to answer a simple question to proceed to the task (don't worry, you'll have unlimited attempts to get it right).</p>"+
          "</div>",
          "<div style='font-size:1.5em;max-width:1600px;line-height:1.25'><p>The task will consist of 2 sections: a training section consisting of 6 blocks of trials, and a short test section at the end.</p>"+
            "<p>You will receive instructions for the test phase once you have completed the training.</p>"+
          "</div>",
          "<div style='font-size:1.25em;max-width:1600px;line-height:1.25'><p>Within the training section, each trial will begin with a 1 second fixation cross, followed by a stimulus consisting of 2 symbols.</p>"+
            "<p>One symbol will be correct, and the other incorrect, but at first you won't know which is which!</p>" + 
            "<div style='width: 100%; display: flex; justify-content: center; flex-direction: row;'>"+
              "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/fixation_instr.png'></img>" +
                "<p class='small'><strong>Fixation cross</strong></p></div>" +
              "<div><img style='height: 30vh; max-height:350px; max-width: 500px' src='img/stimulus_instr.png'></img>" +
                "<p class='small'><strong>Stimulus</strong></p></div>"+
            "</div>"+
            "<p>There is no <em>absolute</em> right answer, but some symbols will have a higher chance of being correct. Try to pick the symbol you think is most likely correct.</p>" +
              "<p>Press the <strong>F</strong> key to select the <strong>left</strong> symbol, and the <strong>J</strong> key to select the <strong>right</strong> symbol - you will have 4 seconds to decide!</p>"+
          "</div>",
          "<div style='font-size:1.25em;max-width:1600px;line-height:1.25'><p>After you choose one of the symbols, you will then receive feedback. Correct answers will be rewarded with 25 points.</p>"+
            "<div style='width: 100%; display: flex; justify-content: center; flex-direction: row;'>"+
              "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/correct_feedback.png'></img>"+
              "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/incorrect_feedback.png'></img>"+
            "</div>"+
            "<p>If you score in the top 30% of the experiment, you will win a <strong>£1</strong> bonus, and if you score in the top 10% you will win a <strong>£2</strong> bonus!</p>"+
            "<p>Your goal is to win as many points as possible in order to maximise your chance of receiving the bonus."+
          "</div>",
          "<div style='font-size:1.25em;max-width:1600px;line-height:1.25'><p>Lastly, you will be asked a question about how you are currently feeling (the below is an image of how it will look, no need to answer).</p>"+
            "<img style='height: 30vh;max-height:350px; max-width: 850px' src='img/question_instr.png'></img>"+
            "<p>When you reach this question, simply use your mouse to move the slider to the position that best captures your feelings at that particular moment.</p>"+
            "<p>Feel free to re-read the instructions on previous pages, and then press <em>Next</em> to proceed.</p>"+
          "</div>"
  ],
  show_clickable_nav: true,
  allow_keys: false,
  show_page_number: true,
  button_label_previous: 'Prev'
};
timeline.push(instructions);

let instructions_video = {
  type: 'video-button-response',
  prompt: 'Watch the video above if you\'d like these instructions explained further, and/or to see a visual demonstration of the task.',
  stimulus: ['video/General.mp4'],
  choices: ['Continue'],
  max_width: 1280,
  max_height: 720,
  margin_vertical: '2em',
  controls: true,
  autoplay: false,
  response_allowed_while_playing: true
}
timeline.push(instructions_video);

let instructions_quiz = {
  type: 'survey-html-form',
  html: '<p style="font-size:1.5em;line-height:2;color:#ff6663">A short quiz on the instructions before you start the task!</p>'+
        '<p style="font-size:1.25em;line-height:2">What should you do to win as many points as possible, maximising your chance of the bonus payments? <strong>Choose all that apply.</strong></p>'+
          '<div class="row-questions" style="max-width: 1440px">'+
            '<div class="column-questions">'+    
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="A" name="quiz" value="A">'+
                  '<label style="margin-left:0.5em;" for="A">Press one button the entire time, no matter whether you win or lose points</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="B" name="quiz" value="B">'+
                  '<label style="margin-left:0.5em;" for="B">Learn which symbol in each pair is more likely to be “correct” and give you points, and choose it</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="C" name="quiz" value="C">'+
                  '<label style="margin-left:0.5em;" for="C">Switch your choices on every trial, no matter whether you win or lose points</label>'+
              '</p>'+
            '</div>'+
            '<div class="column-questions">'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="D" name="quiz" value="D">'+
                  '<label style="margin-left:0.5em;" for="D">Answer the questions about how you are feeling dishonestly</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="E" name="quiz" value="E">'+
                  '<label style="margin-left:0.5em;" for="E">Learn which symbol in each pair is more likely to be “incorrect” and not give you points, and avoid it</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="F" name="quiz" value="F">'+
                  '<label style="margin-left:0.5em;" for="F">Answer the questions about how you are feeling completely honestly throughout the task</label>'+
              '</p>'+
            '</div>'+                 
          '</div>',
  data: {test_part: 'test_quiz'},
  checkbox_required: true,
  dataAsArray: true,
  on_finish: function(data) {
    let answers = jsPsych.data.get().last(1).values()[0].responses;
    if ((answers.includes("B") && answers.includes("E") && answers.includes("F")) && (!answers.includes("A") && !answers.includes("C") && !answers.includes("D"))) {
      data.quiz_correct = true;
      } else {
      data.quiz_correct = false;
    }
  }
};

let instructions_quiz_retry = {
  type: 'survey-html-form',
  html: '<p style="font-size:1.25em;line-height:2">What should you do to win as many points as possible, maximising your chance of the bonus payments? <strong>Choose all that apply.</strong></p>'+
          '<div class="row-questions" style="max-width: 1440px">'+
            '<div class="column-questions">'+    
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="A" name="quiz" value="A">'+
                  '<label style="margin-left:0.5em;" for="A">Press the same button the entire time, no matter whether you win or lose points</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="B" name="quiz" value="B">'+
                  '<label style="margin-left:0.5em;" for="B">Learn which symbol in each pair is more likely to be “correct” and give you points, and choose it</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="C" name="quiz" value="C">'+
                  '<label style="margin-left:0.5em;" for="C">Switch your choices on every trial, no matter whether you win or lose points</label>'+
              '</p>'+
            '</div>'+
            '<div class="column-questions">'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="D" name="quiz" value="D">'+
                  '<label style="margin-left:0.5em;" for="D">Answer the questions about how you are feeling dishonestly</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="E" name="quiz" value="E">'+
                  '<label style="margin-left:0.5em;" for="E">Learn which symbol in each pair is more likely to be “incorrect” and not give you points, and avoid it</label>'+
              '</p>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="F" name="quiz" value="F">'+
                  '<label style="margin-left:0.5em;" for="F">Answer the questions about how you are feeling completely honestly throughout the task</label>'+
              '</p>'+
            '</div>'+                 
          '</div>',
  data: {test_part: 'test_quiz'},
  checkbox_required: true,
  dataAsArray: true,
  on_finish: function(data) {
    let answers = jsPsych.data.get().last(1).values()[0].responses;
    let quiz_q_no = jsPsych.data.get().filter({test_part: 'test_quiz'}).count();
    if (!quiz_q_no) {
      quiz_q_no==1
    }
    data.quiz_q_no = quiz_q_no
    if ((answers.includes("B") && answers.includes("E") && answers.includes("F")) && (!answers.includes("A") && !answers.includes("C") && !answers.includes("D"))) {
      data.quiz_correct = true;
      } else {
      data.quiz_correct = false;
    }
  }
};

let instructions_repeat = {
  type: 'instructions',
  pages: [
    "<p style='font-size:1.5em;line-height:2;color:red'>That wasn't quite right. Here's a quick reminder of what to do during the task.</p>"+
    "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
      "<p>For the first six blocks of the task, each trial will begin with a 1 second fixation cross, followed by a stimulus consisting of 2 symbols.</p>"+
        "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/stimulus_instr.png'></img>"+
      "<p>One symbol will be correct, and the other incorrect, but at first you won't know which is which! There is no absolute right answer, but some symbols will have a higher chance of being correct.</p>"+
      "<p>Try to pick the symbol you think is <em>most likely</em> to be correct.</p>"+
    "</div>",
    "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
      "<p>Press the <strong>F</strong> key to select the <em>left</em> symbol, and the <strong>J</strong> key to select the <em>right</em> symbol - you will have 4 seconds to decide!</p>"+
      "<p>After you choose one of the symbols, you will then receive feedback. Correct answers will be rewarded with 25 points.</p>"+
        "<div style='width: 100%; display: flex; justify-content: center; flex-direction: row;'>"+
          "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/correct_feedback.png'></img>"+
          "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/incorrect_feedback.png'></img>"+
        "</div>"+
      "<p>If you score in the top 30% of the experiment, you will win a £1 bonus, and if you score in the top 10% you will win a £2 bonus!</p>"+
    "</div>",
    "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
      "<p>After you receive feedback, you will be asked a question about how you are currently feeling. Please answer this honestly.</p>"+
        "<img style='height: 30vh;max-height:350px; max-width: 850px' src='img/question_instr.png'></img>"+
      "<p><strong>Remember</strong>: your goal is to win as many points as possible in order to maximise your chance of receiving the bonus.</p>"+
      "<p>Press <em>Next</em> to try the question again.</p>"+
    "</div>"
  ],
  show_clickable_nav: true,
  allow_keys: false,
  show_page_number: true,
  button_label_previous: 'Prev'
};

let instructions_repeat_no_feedback = {
  conditional_function: function() {
    let button_press = jsPsych.data.get().last(1).values()[0].button_pressed;
    if (button_press==0) {
      return true;
    } else {
      return false;
    }
  },
  timeline: [
    {
      type: 'instructions',
      pages: [
        "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
          "<p>For the first six blocks of the task, each trial will begin with a 1 second fixation cross, followed by a stimulus consisting of 2 symbols.</p>"+
            "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/stimulus_instr.png'></img>"+
          "<p>One symbol will be correct, and the other incorrect, but at first you won't know which is which! There is no absolute right answer, but some symbols will have a higher chance of being correct.</p>"+
          "<p>Try to pick the symbol you think is <em>most likely</em> to be correct.</p>"+
        "</div>",
        "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
          "<p>Press the <strong>F</strong> key to select the <em>left</em> symbol, and the <strong>J</strong> key to select the <em>right</em> symbol - you will have 4 seconds to decide!</p>"+
          "<p>After you choose one of the symbols, you will then receive feedback. Correct answers will be rewarded with 25 points.</p>"+
            "<div style='width: 100%; display: flex; justify-content: center; flex-direction: row;'>"+
              "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/correct_feedback.png'></img>"+
              "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/incorrect_feedback.png'></img>"+
            "</div>"+
          "<p>If you score in the top 30% of the experiment, you will win a £1 bonus, and if you score in the top 10% you will win a £2 bonus!</p>"+
        "</div>",
        "<div style='font-size:1.25em;max-width:1440px;line-height:1.5'>"+
          "<p>After you receive feedback, you will be asked a question about how you are currently feeling. Please answer this honestly.</p>"+
            "<img style='height: 30vh;max-height:350px; max-width: 850px' src='img/question_instr.png'></img>"+
          "<p><strong>Remember</strong>: your goal is to win as many points as possible in order to maximise your chance of receiving the bonus.</p>"+
          "<p>Press <em>Next</em> to try the question again.</p>"+
        "</div>"
      ],
      show_clickable_nav: true,
      allow_keys: false,
      show_page_number: true,
      button_label_previous: 'Prev'
    }
  ]  
};

let instructions_quizfail = {
  conditional_function: function() {
    let quiz_correct = jsPsych.data.get().last(1).values()[0].quiz_correct;
    if (quiz_correct) {
      return false
    } else {
      return true
    }
  },
  timeline: [instructions_repeat]
};

let feedback_for_quiz = {
  type: 'html-button-response',
  stimulus: "<p style='font-size:1.5em;line-height:2;color:red'>That wasn't quite right.</p>"+
          "<p style='font-size:1.25em;line-height:2;'>Press one of the buttons below to either re-read the instructions or try the question again.</p>",
  choices: ['Re-read instructions', 'Try question again']
};

let instructions_loop = {
  conditional_function: function() {
    let quiz_correct = jsPsych.data.get().last(1).values()[0].quiz_correct;
    if (quiz_correct) {
      return false
    } else {
      return true
    }
  },
  timeline: [feedback_for_quiz, instructions_repeat_no_feedback]
};

loop_node = {
  timeline: [instructions_quiz_retry, instructions_loop],
  conditional_function: function() {
    let quiz_correct = jsPsych.data.get().filter({test_part: 'test_quiz'}).last(1).values()[0].quiz_correct;
    if (quiz_correct) {
      return false;
    } else {
      return true;
    }
  },
  loop_function: function() {
    let quiz_correct = jsPsych.data.get().filter({test_part: 'test_quiz'}).last(1).values()[0].quiz_correct;
    if (quiz_correct) {
      return false;
    } else {
      return true;
    }
  }
};

timeline.push(instructions_quiz, instructions_quizfail, loop_node);

/* initial message */
let init = {
type: 'html-keyboard-response',
stimulus: 
  '<div style="line-height:1.5;max-width:1440px">'+
    '<p style="font-size:1.75em">Get ready! Place your fingers on the <strong>F</strong> and <strong>J</strong> keys, and then press any key to begin the experiment.</p>'+
    '<p style="font-size:1.25em"><strong>Remember</strong>: your goal is to win as many points as possible in order to maximise your chance of receiving the bonus, '+
      'by picking the symbol you think is most likely correct in each pair.</p>'+
  '</div>'
};
timeline.push(init);

let training_block = {
  timeline: [
    {
      type: 'html-keyboard-response',
      stimulus: '<div class="fade-in3" style="font-size:5em">+</div>',
      choices: jsPsych.NO_KEYS,
      trial_duration: 1000,
      data: { test_part: 'fixation' },
      on_finish: function(data) {
        data.combination = shuffle([1,2])[0]
      }
    },
    {
      type: "html-keyboard-response",
      stimulus: function() {
        let order = jsPsych.data.get().last(1).values()[0].combination;
        if (order==1) {
          return jsPsych.timelineVariable('pair1', true)
        } else if (order==2) {
          return jsPsych.timelineVariable('pair2', true)
        }

      },
      choices: ['f', 'j'],
      data: function() {
        let order = jsPsych.data.get().last(1).values()[0].combination;
        if (order==1) {
          return jsPsych.timelineVariable('data1', true)
        } else if (order==2) {
          return jsPsych.timelineVariable('data2', true)
        }
      },
      trial_duration: 4000,
      on_finish: function(data){
        data.glyph_seq = glyphs
        data.trial_no = jsPsych.data.get().filter({test_part: 'fixation'}).count()
        data.correct = data.key_press == jsPsych.pluginAPI.convertKeyCharacterToKeyCode(data.correct_response);
        if(data.correct) {
          data.points = 25
        }
        else {
          data.points = 0
        }
        data.timeout = !data.rt;
      }
    },
    {
      type: "html-keyboard-response",
      stimulus: function(){
        let last_trial_correct = jsPsych.data.get().last(1).values()[0].correct;
        let last_trial_timeout = jsPsych.data.get().last(1).values()[0].timeout;
        let last_trial_payout = jsPsych.data.get().last(1).values()[0].points;
        let cumsum_points = jsPsych.data.get().select('points').sum();
        if(last_trial_correct) {
            return '<div class="center">'+
                      '<div class="pyro">'+
                        '<div class="before"></div>'+
                        '<div class="after"></div>'+
                      '</div>'+
                      '<p><h1><div style="font-size:2.5em;color:#9462e9;text-align:center">Correct!</div></h1><p>'+
                      '<p><br></br><div class="fade-in1" style="font-size:2em;color:#ff6663;text-align:center">You won <strong>'+last_trial_payout+' points</strong>!</div></p>'+
                    '</div>'+
                    '<div class="centerbottom">'+
                      '<h4 class="wordCarousel">'+
                          '<div class="fade-in2">'+
                          '<span>Total points: </span>'+
                          '<div>' +
                            '<ul class="flip2">'+
                                '<li>'+cumsum_points+'</li>'+
                            '</ul>'+
                          '</div>'+
                      '</h4>'+
                    '</div>'
        } else if (!last_trial_correct && !last_trial_timeout) {
            return '<input type="incorrect" value="Incorrect.">';
        } else {
            return '<p><div style="font-size:2.5em;color:red">No response detected.</div></p>';
        }
      },
      choices: jsPsych.NO_KEYS,
      trial_duration: 2000,
      data: {test_part: 'feedback'},
      on_finish: function(data) {
        let trial_no = jsPsych.data.get().last(2).values()[0].trial_no;

        if (trial_no == 1 || Number.isInteger((trial_no-1)/3)) {
          data.question_array = shuffle([1,2,3]);
          data.question_no_of_3 = 1;
        } else if (trial_no == 2 || Number.isInteger((trial_no-2)/3)) {
          data.question_array = jsPsych.data.get().filter({test_part: 'feedback'}).last(2).values()[0].question_array;
          data.question_no_of_3 = 2;
        } else {
          data.question_array = jsPsych.data.get().filter({test_part: 'feedback'}).last(2).values()[0].question_array;
          data.question_no_of_3 = 3;
        }  
      }
    },
    {
      type:'html-slider-response',
      stimulus: function() {
        let question_no_of_3 = jsPsych.data.get().last(1).values()[0].question_no_of_3;
        let question_array = jsPsych.data.get().last(1).values()[0].question_array;
        if (question_no_of_3 == 1) {
          question = question_array[0];
        } else if (question_no_of_3 == 2) {
          question = question_array[1];
        } else {
          question = question_array[2];
        }
        
        if (question==1) {
          return 'How <strong><em>happy</strong></em> are you at this moment?'
        } else if (question==2) {
          return 'How <strong><em>confident</strong></em> are you feeling in your answers at this moment?'
        } else if (question==3) {
          return 'How <strong><em>engaged</strong></em> are you feeling at this moment?'
        }
      },
      labels: function() {
        let question_no_of_3 = jsPsych.data.get().last(1).values()[0].question_no_of_3;
        let question_array = jsPsych.data.get().last(1).values()[0].question_array;
        if (question_no_of_3 == 1) {
          question = question_array[0];
        } else if (question_no_of_3 == 2) {
          question = question_array[1];
        } else {
          question = question_array[2];
        }

        if (question==1) {
          return ['Strongly negative', 'Strongly positive']
        } else if (question==2) {
          return ['Uncertain', 'Certain']
        } else if (question==3) {
          return ['Bored', 'Motivated']
        }
      },
      data: {test_part: 'question'},
      slider_start: function() {
        return jsPsych.randomization.sampleWithoutReplacement([25, 35, 45, 55, 65, 75],1)[0];
      },
      require_movement: true,
      slider_width: 400,
      on_finish: function(data) { 
        data.question=jsPsych.data.get().last(1).values()[0].question;
      }
    }
  ],
  timeline_variables: [
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[1]+'</div>', data1: { test_part: 'AB', correct_response: 'f' }, 
      pair2: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[0]+'</div>', data2: { test_part: 'BA', correct_response: 'j' } },
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[1]+'</div>', data1: { test_part: 'AB_rev', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[0]+'</div>', data2: { test_part: 'BA_rev', correct_response: 'f' } },
    { pair1: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[3]+'</div>', data1: { test_part: 'CD', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[2]+'</div>', data2: { test_part: 'DC', correct_response: 'j' } },
    { pair1: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[3]+'</div>', data1: { test_part: 'CD_rev', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[2]+'</div>', data2: { test_part: 'DC_rev', correct_response: 'f' } },
    { pair1: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[5]+'</div>', data1: { test_part: 'EF', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[4]+'</div>', data2: { test_part: 'FE', correct_response: 'j' } },
    { pair1: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[5]+'</div>', data1: { test_part: 'EF_rev', correct_response: 'j' },       
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[4]+'</div>', data2: { test_part: 'FE_rev', correct_response: 'f' } }
  ],
  sample: {
    type: 'fixed-repetitions',
    size: [16,4,14,6,12,8] // should be 16,4,14,6,12,8
  }
}

let block_init = {
  type: 'html-keyboard-response',
  stimulus: 
  '<div style="line-height:1.5;max-width:1600px">'+
    '<p style="font-size:1.75em;">Get ready! Place your fingers on the <strong>F</strong> and <strong>J</strong> keys, and then press any key to begin the next training block.</p>'+
    '<p style="font-size:1.25em;"><strong>Remember</strong>: your goal is to win as many points as possible in order to maximise your chance of receiving the bonus, '+
      'by picking the symbol you think is most likely correct in each pair.</p>'+
  '</div>'
};

let block_init_final = {
  type: 'html-keyboard-response',
  stimulus: 
    '<div style="line-height:1.5;max-width:1440px">'+
      '<p style="font-size:1.75em;">Get ready! Place your fingers on the <strong>F</strong> and <strong>J</strong> keys, and then press any key to begin the final training block.</p>'+
      '<p style="font-size:1.25em;"><strong>Remember</strong>: your goal is to win as many points as possible in order to maximise your chance of receiving the bonus, '+
        'by picking the symbol you think is most likely correct in each pair.</p>'+
    '</div>'
};

let fatigue_begin = {
  type: 'html-slider-response',
  stimulus: 'How <strong><em>fatigued</strong></em> do you feel compared to the beginning of the experiment?',
  labels: ['Less tired', 'More tired'],
  data: {test_part: 'fatigue_question'},
  slider_start: function() {
    return jsPsych.randomization.sampleWithoutReplacement([25, 35, 45, 55, 65, 75],1)[0];
  },
  require_movement: true,
  slider_width: 400
}

let fatigue_main = {
  type: 'html-slider-response',
  stimulus: 'How <strong><em>fatigued</strong></em> do you feel compared to the beginning of the block?',
  labels: ['Less tired', 'More tired'],
  data: {test_part: 'fatigue_question'},
  slider_start: function() {
    return jsPsych.randomization.sampleWithoutReplacement([25, 35, 45, 55, 65, 75],1)[0];
  },
  require_movement: true,
  slider_width: 400
}


let block1_complete = {
    type:'external-html',
    url: "extra_html/congrats_1.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
}

let block2_complete = {
    type:'external-html',
    url: "extra_html/congrats_2.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
}

let block3_complete = {
    type:'external-html',
    url: "extra_html/congrats_3.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
}

let block4_complete = {
    type:'external-html',
    url: "extra_html/congrats_4.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
}

let block5_complete = {
    type:'external-html',
    url: "extra_html/congrats_5.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
}

let training_complete = {
    type:'external-html',
    url: "extra_html/congrats_endtraining.html",
    cont_btn: "continue",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'training_complete'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
      data.total_points = jsPsych.data.get().select('points').sum().toFixed([2]);
    }
}

let pre_test = {
  type: 'html-keyboard-response',
  stimulus: function() {
    let total_points = Math.round(jsPsych.data.get().last(1).values()[0].total_points);
    return "<div style='font-size:2em;line-height:1'><h2>You won a total of <span style='color:#ff8001;'>"+total_points+" points</span> over the course of the training trials!</h2>"+
            "<p>Now it's time to test what you've learnt. Press any key to continue.</p></div>"
  }
};

let test_instructions = {
  type: 'instructions',
  pages: ["<div style='font-size:1.5em'>"+
            "<p>As before, two symbols will appear on the screen, and you should pick the left or right symbol with the <strong>F</strong> or <strong>J</strong> key respectively.</p>"+
            "<img style='height: 30vh; max-height:350px; max-width: 500px' src='img/stimulus_instr.png'></img>"+
          "</div>",
          "<div style='font-size:1.5em'><p>However, during this final section you will <em>not</em> receive feedback!</p>"+
            "<p>You may also see combinations of symbols you haven't seen before: try to pick the symbol that 'feels' correct to you.</p>"+
          "<p>Press <em>Next</em> once you have read all the instructions, and are ready to begin the test.</p></div>"
    ],
  show_clickable_nav: true,
  allow_keys: false,
  show_page_number: true,
  button_label_previous: 'Prev'
};

let test_init = {
  type: 'html-keyboard-response',
  stimulus: 
    '<div style="line-height:1.5;max-width:1600px">'+
      '<p style="font-size:1.75em;">Get ready! Place your fingers on the <strong>F</strong> and <strong>J</strong> keys, and then press any key to begin the test block.</p>'+
      '<p style="font-size:1.25em;"><strong>Remember</strong>: your goal here is to simply pick the symbol you feel is most likely correct in each pair, based on what you learnt during training.</p>'+
    '</div>'
};

let test_block = {
  timeline: [
    {
      type: 'html-keyboard-response',
      stimulus: '<div class="fade-in3" style="font-size:5em">+</div>',
      choices: jsPsych.NO_KEYS,
      trial_duration: 1000,
      data: { test_part: 'fixation_test' },
      on_finish: function(data) {
        data.combination = shuffle([1,2])[0]
      }
    },
    {
      type: "html-keyboard-response",
      stimulus: function() {
        let order = jsPsych.data.get().last(1).values()[0].combination;
        if (order==1) {
          return jsPsych.timelineVariable('pair1', true)
        } else if (order==2) {
          return jsPsych.timelineVariable('pair2', true)
        }

      },
      choices: ['f', 'j'],
      data: function() {
        let order = jsPsych.data.get().last(1).values()[0].combination;
        if (order==1) {
          return jsPsych.timelineVariable('data1', true)
        } else if (order==2) {
          return jsPsych.timelineVariable('data2', true)
        }
      },
      trial_duration: 4000,
      on_finish: function(data){
        data.glyph_seq = glyphs;
        data.test_trial_no = jsPsych.data.get().filter({test_part: 'fixation_test'}).count();
        data.correct = data.key_press == jsPsych.pluginAPI.convertKeyCharacterToKeyCode(data.correct_response);
        data.timeout = !data.rt;

        let trial_no = jsPsych.data.get().filter({test_part: 'fixation_test'}).count();

        if (trial_no == 1 || Number.isInteger((trial_no-1)/3)) {
          data.question_array = shuffle([1,2,3]);
          data.question_no_of_3 = 1;
        } else if (trial_no == 2 || Number.isInteger((trial_no-2)/3)) {
          data.question_array = jsPsych.data.get().filter({test_part: 'question_test'}).last(1).values()[0].prev_question_array;
          data.question_no_of_3 = 2;
        } else {
          data.question_array = jsPsych.data.get().filter({test_part: 'question_test'}).last(1).values()[0].prev_question_array;
          data.question_no_of_3 = 3;
        }  
      }
    },
    {
      type:'html-slider-response',
      stimulus: function() {
        let question_no_of_3 = jsPsych.data.get().last(1).values()[0].question_no_of_3;
        let question_array = jsPsych.data.get().last(1).values()[0].question_array;
        if (question_no_of_3 == 1) {
          question = question_array[0];
        } else if (question_no_of_3 == 2) {
          question = question_array[1];
        } else {
          question = question_array[2];
        }
        
        if (question==1) {
          return 'How <strong><em>happy</strong></em> are you at this moment?'
        } else if (question==2) {
          return 'How <strong><em>confident</strong></em> are you feeling in your answers at this moment?'
        } else if (question==3) {
          return 'How <strong><em>engaged</strong></em> are you feeling at this moment?'
        }
      },
      labels: function() {
        let question_no_of_3 = jsPsych.data.get().last(1).values()[0].question_no_of_3;
        let question_array = jsPsych.data.get().last(1).values()[0].question_array;
        if (question_no_of_3 == 1) {
          question = question_array[0];
        } else if (question_no_of_3 == 2) {
          question = question_array[1];
        } else {
          question = question_array[2];
        }

        if (question==1) {
          return ['Strongly negative', 'Strongly positive']
        } else if (question==2) {
          return ['Uncertain', 'Certain']
        } else if (question==3) {
          return ['Bored', 'Motivated']
        }
      },
      data: {test_part: 'question_test'},
      slider_start: function() {
        return jsPsych.randomization.sampleWithoutReplacement([25, 35, 45, 55, 65, 75],1)[0];
      },
      require_movement: true,
      slider_width: 400,
      on_finish: function(data) { 
        data.question=jsPsych.data.get().last(1).values()[0].question;
        data.prev_question_array=jsPsych.data.get().last(2).values()[0].question_array;
      }
    }
  ],
    timeline_variables: [
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[1]+'</div>', data1: { test_part: 'AB_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[0]+'</div>', data2: { test_part: 'BA_test', correct_response: 'j' } }, // B=20%; A=80%
    { pair1: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[3]+'</div>', data1: { test_part: 'CD_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[2]+'</div>', data2: { test_part: 'DC_test', correct_response: 'j' } }, // D=30%; C=70%
    { pair1: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[5]+'</div>', data1: { test_part: 'EF_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[4]+'</div>', data2: { test_part: 'FE_test', correct_response: 'j' } }, // F=40%; E=60%
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[2]+'</div>', data1: { test_part: 'AC_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[0]+'</div>', data2: { test_part: 'CA_test', correct_response: 'j' } }, // C=70%; A=80%
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[3]+'</div>', data1: { test_part: 'AD_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[0]+'</div>', data2: { test_part: 'DA_test', correct_response: 'j' } }, // D=30%; A=80%
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[4]+'</div>', data1: { test_part: 'AE_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[0]+'</div>', data2: { test_part: 'EA_test', correct_response: 'j' } }, // E=60%; A=80%
    { pair1: '<div style="font-size:7em;">'+glyphs[0]+' '+glyphs[5]+'</div>', data1: { test_part: 'AF_test', correct_response: 'f' },        
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[0]+'</div>', data2: { test_part: 'FA_test', correct_response: 'j' } }, // F=40%; A=80%
    { pair1: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[2]+'</div>', data1: { test_part: 'BC_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[1]+'</div>', data2: { test_part: 'CB_test', correct_response: 'f' } }, // C=70%; B=20%
    { pair1: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[3]+'</div>', data1: { test_part: 'BD_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[1]+'</div>', data2: { test_part: 'DB_test', correct_response: 'f' } }, // D=30%; B=20%
    { pair1: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[4]+'</div>', data1: { test_part: 'BE_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[1]+'</div>', data2: { test_part: 'EB_test', correct_response: 'f' } }, // E=60%; B=20%
    { pair1: '<div style="font-size:7em;">'+glyphs[1]+' '+glyphs[5]+'</div>', data1: { test_part: 'BF_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[1]+'</div>', data2: { test_part: 'FB_test', correct_response: 'f' } }, // F=40%; B=20%
    { pair1: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[4]+'</div>', data1: { test_part: 'CE_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[2]+'</div>', data2: { test_part: 'EC_test', correct_response: 'j' } }, // E=60%; C=70%
    { pair1: '<div style="font-size:7em;">'+glyphs[2]+' '+glyphs[5]+'</div>', data1: { test_part: 'CF_test', correct_response: 'f' },
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[2]+'</div>', data2: { test_part: 'FC_test', correct_response: 'j' } }, // F=40%; C=70%
    { pair1: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[4]+'</div>', data1: { test_part: 'DE_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[4]+' '+glyphs[3]+'</div>', data2: { test_part: 'ED_test', correct_response: 'f' } }, // E=60%; D=30%
    { pair1: '<div style="font-size:7em;">'+glyphs[3]+' '+glyphs[5]+'</div>', data1: { test_part: 'DF_test', correct_response: 'j' },
      pair2: '<div style="font-size:7em;">'+glyphs[5]+' '+glyphs[3]+'</div>', data2: { test_part: 'FD_test', correct_response: 'f' } } // F=40%; D=30%
  ],
  sample: {
    type: 'fixed-repetitions',
    size: [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
  }
};

let exp_complete = {
    type:'external-html',
    url: "extra_html/congrats_complete.html",
    cont_btn: "finish",
    force_refresh: true,
    execute_script: true,
    data: {test_part: 'congrats'},
    on_finish: function(data) { 
      data.block_complete = true;
      data.total_blocks = jsPsych.data.get().filter({block_complete: true}).count();
    }
};

timeline.push(training_block, fatigue_begin, block1_complete, block_init, training_block, fatigue_main, block2_complete, block_init, 
training_block, fatigue_main, block3_complete, block_init, training_block, fatigue_main, block4_complete, block_init, training_block, 
fatigue_main, block5_complete, block_init_final, training_block, fatigue_main, training_complete, pre_test, test_instructions, 
test_init, test_block, exp_complete);


/* start the experiment */

/* 
jatos.onLoad(function () {
  jsPsych.init({
    timeline: timeline,
    max_load_time: 120000,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, function() {
        jatos.startComponentByPos(5)
      });
    }
  });
});
*/

jatos.onLoad(function () {
  prolific_id = jatos.urlQueryParameters.PROLIFIC_PID;
  study_id = jatos.urlQueryParameters.STUDY_ID;
  session_id = jatos.urlQueryParameters.SESSION_ID;
  jsPsych.data.addProperties({prolific_id: prolific_id, study_id: study_id, session_id: session_id});
  jsPsych.init({
    timeline: timeline,
    max_load_time: 120000,
    on_finish: function() {
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, function() {
        jatos.startComponentByPos(5)
      });
    }
  });
});
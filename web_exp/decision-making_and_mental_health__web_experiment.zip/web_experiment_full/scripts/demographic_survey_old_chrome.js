/*
* Demographic Questions
*/

timeline=[]

let welcome = {
  type: 'html-keyboard-response',
  stimulus: '<p style="font-size:2em;line-height:1.2;color:#9ec1cf">Welcome to the experiment.</p>'+
            '<p style="font-size:1.5em;line-height:1.2;max-width:1440px">In order to complete the main component of the experiment, you will be required to press keys on a keyboard. '+
            'Please switch to a computer or laptop if you are not using one already (you will be able to use the same link). '+
            '<p style="font-size:1.5em;line-height:1.2;max-width:1440px">If you do not have access to such a device, please return to Prolific and click <span style="color:#ff6663">"Stop without completing"</span> so we can offer your place to someone else.</p>'+
            '<p style="font-size:1.5em;line-height:1.2;max-width:1440px">Press any key to continue.</p>'
};

let init_message = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.25em;line-height:1.5;max-width:1440px;">'+
              '<p style="font-size:1.35em;text-align:center">On the next page, you will be shown an information sheet.</p>'+
                '<p>This document contains information about the aims of this experiment, and what you will be required to do. '+
                'It will also tell you how your data will be collected and stored, and who you can contact should you have any additional concerns.</p>'+
              '<p>Please read this information carefully, and download the PDF for your records if you wish.</p>'+
            '</div>',
  choices: ['Continue']
};


let consent = {
  type: 'survey-html-form',
  html: '<p style="font-size:1.25em"><em>Please read through the document, tick the box underneath the document (at the bottom of the webpage) to confirm you have read it'+
            ', and then press Next to continue.</em></p>'+
        '<div>'+
          '<object data="files/information_sheet.pdf" type="application/pdf" style="width:80vw;height:70vh"></object>'+
        '</div>'+
        '<p style="font-size:1.25em">'+
          '<input type="checkbox" id="consent" name="consent" value="consent_tick" required>'+
            '<label style="margin-left:0.5em" for="consent">I confirm that I have read and understand the volunteer information contained in the above document.</label>'+
        '</p>',
  button_label: 'Next',
  checkbox_required: true,
  list_questions: true,
  required_message: 'Please tick this box to proceed with the experiment. If after reading the information sheet you no longer wish to take part, please return to Prolific '+
  'and select "Stop without completing" so that we can offer your place on this study to someone else.'
};  

let consent2 = {
  type: 'survey-html-form',
  html: '<div style="width: 100%; display: flex; flex-direction:row;justify-content:center;margin-bottom:2em">'+
          '<div style="margin-right:4em;">'+
            '<img src="img/mrccbu.png" width="350px" height="100px"></div>' +
          '<div style="margin-left:4em;margin-top:15px">'+
            '<img src="img/uoc_logo.png" width="350px"></img>'+
          '</div>'+
        '</div>'+
        '<div style="font-size:1.25em;line-height:1.5;text-align:justify;max-width:1440px;padding-left:1em;padding-right:1em">'+
          '<h2 style="font-size:1.5em;text-align:center;line-height:1">CBU ADULT INFORMED CONSENT: WEB-BASED STUDY</h2>'+
          '<p style="font-size:1.35em;text-align:center;line-height:1"><em>Study Title: The interaction between cognition, mental health, and immune responses</em></p>'+
          '<p style="margin-bottom:3em;text-align:center"><span><em>Chief Investigator</em>: Dr Tim Dalgleish</span>'+
            '<span style="margin-left:1.5em"><em>Principal Investigator</em>: Dr Camilla Nord</span>'+
            '<span style="margin-left:1.5em"><em>HBREC Code</em>: HBREC.2020.40</span>'+
            '<span style="margin-left:1.5em"><em>IRAS ID</em>: IRAS 289980</span></p>'+
            '<p><input type="checkbox" id="consent2" name="consent" value="consent_tick" required '+
            'oninvalid="this.setCustomValidity(\'You must tick all boxes to proceed with the experiment. If you no longer wish to take part, please return to Prolific '+
              'and select &#34;Stop without completing&#34 so that we can offer your place on this study to someone else.\')" onchange="this.setCustomValidity(\'\')">'+
            '<label style="margin-left:0.5em" for="consent2">I understand that I can ask questions by contacting the Principal Investigator: Camilla Nord (camilla.nord@mrc-cbu.cam.ac.uk).</label></p>'+
          '<p><input type="checkbox" id="consent3" name="consent" value="consent_tick" required '+
            'oninvalid="this.setCustomValidity(\'You must tick all boxes to proceed with the experiment. If you no longer wish to take part, please return to Prolific '+
              'and select &#34;Stop without completing&#34 so that we can offer your place on this study to someone else.\')" onchange="this.setCustomValidity(\'\')">'+
            '<label style="margin-left:0.5em" for="consent3">I understand that my participation is voluntary. I am free to withdraw at any time, without giving a reason, '+
              'without penalty or affecting my legal rights.</label></p>'+
          '<p><input type="checkbox" id="consent4" name="consent" value="consent_tick" required '+
            'oninvalid="this.setCustomValidity(\'You must tick all boxes to proceed with the experiment. If you no longer wish to take part, please return to Prolific '+
              'and select &#34;Stop without completing&#34 so that we can offer your place on this study to someone else.\')" onchange="this.setCustomValidity(\'\')">'+
            '<label style="margin-left:0.5em" for="consent4">I understand that the information collected about me and research data may be used to support other research '+
              'in the future, and may be shared anonymously with other academic and commercial researchers external to the project within the UK and beyond, but that at '+
              'all times the personal data will be kept confidential in accordance with data protection guidelines.</label></p>'+
          '<p><input type="checkbox" id="consent5" name="consent" value="consent_tick" required '+
            'oninvalid="this.setCustomValidity(\'You must tick all boxes to proceed with the experiment. If you no longer wish to take part, please return to Prolific '+
              'and select &#34;Stop without completing&#34 so that we can offer your place on this study to someone else.\')" onchange="this.setCustomValidity(\'\')">'+
            '<label style="margin-left:0.5em" for="consent5">I understand that on publication, research data may be shared with others through a protected database after '+
              'removing information that might identify me.</label></p>'+
        '</div>',
  button_label: 'Next',
  list_questions: true
};

let disclaimer = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.25em;line-height:1.5;max-width:1440px;">'+
              '<h2 style="font-size:1.5em;margin-bottom:1em;text-align:center">Disclaimer</h2>'+
              '<p>During this study, you will be asked questions regarding your mental and physical health. We understand that sometimes answering these questions '+
                'can make people aware of problems that they may be having with their health. Please think carefully about this before deciding to take part in this study, '+
                'as we are unable to provide any support for health issues you do report during this study. If you do have any concerns about your health, please contact your '+
                'doctor (if in the UK, your GP), who can direct you to the appropriate local clinical service.</p>'+
              '<p> If you have any questions, please contact the Principal Investigator, Dr Camilla Nord either through Prolific Message or email (camilla.nord@mrc-cbu.cam.ac.uk).</p>'+
            '</div>',
  choices: ['Next']
};

let take_part = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.75em;margin-bottom:2.5em">Do you wish to take part in this study?</p>'+
          '<p style="font-size:1.25em">'+
            '<input type="radio" id="YES" name="takepart" value="study_yes" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="YES">Yes, I read the information sheet, checked the boxes on the previous page myself, and agree to take part in the study.</label>'+
          '</p>'+
          '<p style="font-size:1.25em">'+
              '<input type="radio" id="NO" name="takepart" value="study_no">'+
                '<label style="margin-left:0.5em;" for="NO">No, I do not agree to take part in this study.</label>'+
          '</p>'+
        '</div>',
  button_label: 'Start experiment',
  on_finish: function(data) {
    let takepart = jsPsych.data.get().last(1).values()[0].responses;
    if (takepart.includes("study_yes")) {
      data.take_part = 1
    } else {
      data.take_part = 0
    }
  }
};

let stop_leave = {
  conditional_function: function() {
    let take_part = jsPsych.data.get().last(1).values()[0].take_part;
    if (take_part) {
      return false
    } else {
        return true
      }
  },
  timeline: [
    {
      type: 'html-keyboard-response',
      stimulus: '<h2 style="font-size:2em;line-height:1.2;color:#9ec1cf">You have indicated you do not wish to take part, and so will be unable to continue with the study.</h2>'+
                '<p style="font-size:1.25em;line-height:1.2;">Please return to Prolific and click <span style="color:#ff6663">"Stop without completing"</span> so that we are able to offer your place to someone else. Thank you!</p>',
      choices: jsPsych.NO_KEYS
    }
  ]
};

let instructions = {
  type: 'instructions',
  pages: ["<div style='font-size:1.75em;line-height:1.25;max-width:1440px;'>"+
          "<p>The first part of the experiment is a survey with some questions about your background, demographics, and basic medical history.</p></div>",
          "<div style='font-size:1.5em;line-height:1.25;max-width:1440px'>"+
            "<p>Knowing the demographics of the people who take part in our research helps us understand who our participant sample represents.</p>"+
            "<p>As with all other data you provide today, your answers will be kept anonymous and stored securely.</p>"+
            "<p>Press <em>Next</em> to proceed.</p>"+
          "</div>"
          ],
  show_clickable_nav: true,
  allow_keys: false,
  show_page_number: true,
  button_label_previous: 'Prev'
  };

let age = {
  type: 'survey-html-form',
  html: '<p><label style="font-size:1.75em;margin-right:1.5em" for="age">How old are you?</label> <input style="text-align:left;padding:5px" type="number" id="number" name="age" min="18" max="99" required></p>',
  on_finish: function(data) {
    let age_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-9]/g).join('');
    data.age = parseInt(age_str);
  }
};

let gender = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.75em">What is your gender?</p>'+
          '<p style="font-size:1.5em">'+
            '<input type="radio" id="gen_female" name="gen" value="gen_female" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="gen_female">Woman</label>'+
            '<input type="radio" id="gen_male" name="gen" value="gen_male">'+
              '<label style="margin-left:0.5em;margin-right:2em" for="gen_male">Man</label>'+
            '<input type="radio" id="gen_enby" name="gen" value="gen_enby">'+
              '<label style="margin-left:0.5em;margin-right:2em" for="gen_enby">Non-binary</label>'+
            '<input type="radio" id="gen_other" name="gen" value="gen_other">'+
              '<label style="margin-left:0.5em;" for="gen_other">Other</label>'+
          '</p>'+
        '</div>',
  on_finish: function(data) {
    let gend = jsPsych.data.get().last(1).values()[0].responses;
    if (gend.includes("gen_female")) {
      data.gender = "Female"
    } else if (gend.includes("gen_male")) {
      data.gender = "Male"
    } else if (gend.includes("gen_enby")) {
      data.gender = "Non-binary"
    } else {
      data.gender = "Other"
    }
  }
};

let ethnicity = {
  type: 'survey-html-form',
  html: '<p style="font-size:1.75em">Which of these best describes your ethnic group or background?</p>'+
        '<p style="font-size:1.25em">'+
          '<input style="margin-right:1em" type="radio" id="eth_white" name="eth" value="eth_white">'+
            '<label style="margin-right:2em" for="eth_white"><span class="tooltip">White'+
              '<span style="width:220px;left:-4.75em" class="tooltiptext">e.g. English, Welsh, Scottish, Northern Irish, Irish, Gypsy or Irish Traveller, German...</span></span>'+
            '</label>'+
          '<input style="margin-right:1em" type="radio" id="eth_mix" name="eth" value="eth_mix">'+
            '<label style="margin-right:2em" for="eth_mix"><span class="tooltip">Mixed or multiple ethnic groups'+
              '<span class="tooltiptext">e.g. White and Black Carribean, White and Black African, White and Asian...</span></span>'+
            '</label>'+
          '<input style="margin-right:1em" type="radio" id="eth_asia" name="eth" value="eth_asia">'+
            '<label style="margin-right:2em" for="eth_asia"><span class="tooltip">Asian or Asian British'+
              '<span class="tooltiptext">e.g. Indian, Pakistani, Bangladeshi, Chinese...</span></span>'+
            '</label>'+
        '</p>'+
        '<p style="font-size:1.25em">'+
          '<input style="margin-right:1em" type="radio" id="eth_afrocar" name="eth" value="eth_afrocar">'+
            '<label style="margin-right:2em" for="eth_afrocar"><span class="tooltip">'+
              'Black, African, Carribean, or Black British<span class="tooltiptext">e.g. African, Carribean, African American...</span></span>'+
            '</label>'+
          '<input style="margin-right:1em" type="radio" id="eth_other" name="eth" value="eth_other" required >'+
            '<label style="margin-right:2em" for="eth_other">'+
              '<span class="tooltip">Other ethnic group<span class="tooltiptext">e.g. Arab, Pacific Islander, Aboriginal...</span></span>'+
            '</label>'+
        '</p>',
  on_finish: function(data) {
    let ethn = jsPsych.data.get().last(1).values()[0].responses;
    if (ethn.includes("eth_white")) {
      data.ethnicity = "White"
    } else if (ethn.includes("eth_mix")) {
      data.ethnicity = "Mixed"
    } else if (ethn.includes("eth_asia")) {
      data.ethnicity = "Asian"
    } else if (ethn.includes("eth_afrocar")) {
      data.ethnicity = "Black"
    } else {
      data.ethnicity = "Other"
    }
  }
};

let ses = {
  type: 'survey-html-form',
  html: '<div class="img-text-container">'+
          '<div style="font-size:1.25em" class="img-text-container__text">'+
            '<p>Think of this ladder representing where people stand in your country.</p>'+
            '<p>At the top of the ladder are people who are best off – those have the most money, the most education and the most respected jobs.</p>'+
            '<p> At the bottom are the people who are the worst off – who have the least money, least education, and the least respected jobs or no job.</p>'+
            '<p>The higher up you are on this ladder, the closer you are to the people at the very top; the lower you are, the closer you are to the people at the very bottom.</p>'+
            '<p style:"font-size:1.5em"><strong>Where would you place yourself on this ladder? Select the number that best matches where you think you fit.</strong></p>'+
            '<p style="font-size:1.25em">'+
              '<input type="radio" id="num1" name="num" value="num1" required>'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num1">1</label>'+
              '<input type="radio" id="num2" name="num" value="num2">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num2">2</label>'+
              '<input type="radio" id="num3" name="num" value="num3">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num3">3</label>'+
              '<input type="radio" id="num4" name="num" value="num4">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num4">4</label>'+
              '<input type="radio" id="num5" name="num" value="num5">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num5">5</label>'+
              '<input type="radio" id="num6" name="num" value="num6">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num6">6</label>'+
              '<input type="radio" id="num7" name="num" value="num7">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num7">7</label>'+
              '<input type="radio" id="num8" name="num" value="num8">'+
                '<label style="margin-left:0.25em;margin-right:1em" for="num8">8</label>'+
              '<input type="radio" id="num9" name="num" value="num9">'+
                '<label style="margin-left:0.25em;" for="num9">9</label>'+
            '</p>'+
          '</div>'+
          '<img class="img-text-container__image" src="img/SES_ladder.png"></img>'+
        '</div>',
  on_finish: function(data) {
    let ses_rel = jsPsych.data.get().last(1).values()[0].responses.match(/[0-9]/g);
    data.ses = parseInt(ses_rel);
  }
};

let income= {
  type: 'survey-html-form',
  html: '<p>'+
          '<label style="font-size:1.5em;margin-right:1.5em;line-height:2" for="income">What was your approximate personal total year income (before taxes) '+
            'last year (to the nearest £100; guessing is fine)?'+
          '</label>'+
        '</p>'+
        '<p>'+
          '<input style="width:4.5em;height:1.25em;font-size:1.25em;text-align:right" type="number" id="number" name="income" min="0" step="100" required>'+
          '<span style="margin-left:1em;" class="dropdown">'+
            '<select style="font-size:1.25em;" id="currency" name="currency" id="dropdown" required>'+
              '<option id="gbp" name="income" value="gbp">GBP (£)</option>'+
              '<option id="usd" name="income" value="usd">USD ($)</option>'+
              '<option id="eur" name="income" value="eur">EUR (€)</option>'+
            '</select>'+
          '</span>'+
        '</p>',
  on_finish: function(data) {
    let curr = jsPsych.data.get().last(1).values()[0].responses
    let inc = jsPsych.data.get().last(1).values()[0].responses.match(/[0-9]/g).join('');
    data.income = parseInt(inc);
    if (curr.includes("gbp")) {
      data.currency = "GBP"
    } else if (curr.includes("usd")) {
      data.currency = "USD"
    } else if (curr.includes("eur")) {
      data.currency = "EUR"
    }
  }
};

let english = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.75em;line-height:2">How proficient are you at English?</p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1">'+
            '<input style="margin-right:1em" type="radio" id="eng_native" name="eng" value="eng_native" required>'+
              '<label for="eng_native">Native speaker</label></p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1">'+
            '<input style="margin-right:1em" type="radio" id="eng_c2" name="eng" value="eng_c2">'+
              '<label for="eng_c2">Near native / fluent (C2 level)</label></p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1">'+
            '<input style="margin-right:1em" type="radio" id="eng_c1" name="eng" value="eng_c1">'+
              '<label for="eng_c1">Excellent command / highly proficient in spoken and written English (C1 level)</label></p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1">'+
            '<input style="margin-right:1em" type="radio" id="eng_b2" name="eng" value="eng_b2">'+
              '<label for="eng_b2">Very good command (B2 level)</label></p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1">'+
            '<input style="margin-right:1em" type="radio" id="eng_b1" name="eng" value="eng_b1">'+
            '<label for="eng_b1">Good command / good working knowledge (B1 level)</label></p>'+
          '<p style="font-size:1.25em;text-align:justify;line-height:1;margin-bottom:2em">'+
            '<input style="margin-right:1em" type="radio" id="eng_a12" name="eng" value="eng_a12">'+
            '<label for="eng_a12">Basic communication skills / working knowledge (A1 to A2 level)</label></p>'+
        '</div>',
  on_finish: function(data) {
    let engl = jsPsych.data.get().last(1).values()[0].responses;
    if (engl.includes("eng_native")) {
      data.english = "Native"
    } else if (engl.includes("eng_c2")) {
      data.english = "C2"
    } else if (engl.includes("eng_c1")) {
      data.english = "C1"
    } else if (engl.includes("eng_b2")) {
      data.english = "B2"
    } else if (engl.includes("eng_b1")) {
      data.english = "B1"
    } else {
      data.english = "A1/A2"
    }
  }
};

let japanese = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.5em;line-height:1.2">Can you read Japanese Hiragana characters?</p>'+
          '<p style="font-size:1.25em">'+
            '<input type="radio" id="japan_yes" name="japan" value="japan_yes" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="japan_yes">Yes</label>'+
            '<input type="radio" id="japan_no" name="japan" value="japan_no">'+
              '<label style="margin-left:0.5em;" for="japan_no">No</label>'+
          '</p>'+
        '</div>',
  on_finish: function(data) {
    let japan = jsPsych.data.get().last(1).values()[0].responses;
    if (japan.includes("japan_yes")) {
      data.japanese = 1
    } else {
      data.japanese = 0
    }
  }
};

let neurological = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.5em;line-height:1.2">Have you ever been diagnosed with a neurological disorder (e.g. epilepsy or multiple scelerosis)?</p>'+
          '<p style="font-size:1.25em">'+
            '<input type="radio" id="neur_yes" name="neur" value="neur_yes" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="neur_yes">Yes</label>'+
            '<input type="radio" id="neur_no" name="neur" value="neur_no">'+
              '<label style="margin-left:0.5em;" for="neur_no">No</label>'+
          '</p>'+
        '</div>',
  on_finish: function(data) {
    let neurol = jsPsych.data.get().last(1).values()[0].responses;
    if (neurol.includes("neur_yes")) {
      data.neurological = 1
    } else {
      data.neurological = 0
    }
  }
};

let neurological_disorder = {
  conditional_function: function() {
      let neurological = jsPsych.data.get().last(1).values()[0].neurological;
      if (neurological) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.5em;line-height:2">What neurological disorder(s) have you been diagnosed with? Select all that apply.</p>'+
              '<div class="row-questions">'+
                '<div class="column-questions">'+    
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="ms" name="neur" value="Multiple Sclerosis">'+
                      '<label style="margin-left:0.5em;" for="ms">Multiple Sclerosis (MS)</label>'+
                  '</p>'+
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="epil" name="neur" value="Epilepsy">'+
                      '<label style="margin-left:0.5em;" for="epil">Epilepsy</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions">'+
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="tbi" name="neur" value="Traumatic brain injury">'+
                      '<label style="margin-left:0.5em;" for="tbi">Traumatic brain injury (TBI)</label>'+
                  '</p>'+
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="headache" name="neur" value="Headache disorder">'+
                      '<label style="margin-left:0.5em;" for="headache">Headache disorder</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions">'+
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="PD" name="neur" value="Parkinson\'s disease">'+
                      '<label style="margin-left:0.5em;" for="PD">Parkinson\'s disease (PD)</label>'+
                  '</p>'+
                  '<p style="font-size:1.25em">'+
                    '<input type="checkbox" id="stroke" name="neur" value="Stroke">'+
                      '<label style="margin-left:0.5em;" for="stroke">Stroke</label>'+
                  '</p>'+                 
                '</div>'+
              '</div>'+
                '<p style="font-size:1.25em">'+
                  '<input type="checkbox" id="error" name="neur" value="None">'+
                    '<label style="margin-left:0.5em;margin-right:4em" for="error">No neurological disorder</label>'+
                  '<input type="checkbox" id="other" name="neur" value="Other">'+
                    '<label style="margin-left:0.5em" for="other">Other (please specify)</label>'+
                  '<input style="margin-left:1rem;margin-bottom:1.5em" type="text" id="other_text" name="neur_text">'+
                '</p>',
        checkbox_required: true,
        dataAsArray: true,
        other_text_required: true,
        text_checkbox_pairs: [{checkbox_id: 'other', text_id: 'other_text', required_message: 'Please specify what other neurological disorder(s) you have been diagnosed with.'}],
        on_finish: function(data) {
          let neurol_dis = jsPsych.data.get().last(1).values()[0].responses;
          if (neurol_dis.includes("None")) {
            data.neurological_disorder = "None";
          } else {
            let index = neurol_dis.indexOf('neur_text')
            neurol_dis = neurol_dis.substring(0,index).replace("neur_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"neur,value:/g, "").replace(",name:\"",']');
            data.neurological_disorder = neurol_dis;
            let other_dis_neur_text = jsPsych.data.get().last(1).values()[0].responses.replace(/\, /g,'__').replace(/\; /g,'__').replace(/ /g,'_').replace(/\W/g, '');
            other_dis_neur_text = other_dis_neur_text.substring(other_dis_neur_text.indexOf("neur_text")).replace("neur_text",'').replace("name",'').replace("value",'').replace(/\__/g, ", ").replace(/_/g, ' ');
            if (other_dis_neur_text != '') {
              data.other_neurological_disorder = true
              data.other_neurological_disorder_type = other_dis_neur_text;
            } else {
              data.other_neurological_disorder = false
            }
          }
        }
      }
    ]
  };    

let psych_neurdev = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.5em;line-height:1.25">Have you ever been diagnosed with a mental health or neurodevelopmental condition (e.g. anxiety or autism)?</p>'+
          '<p style="font-size:1.25em">'+
            '<input type="radio" id="psych_yes" name="psych" value="psych_yes" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="psych_yes">Yes</label>'+
            '<input type="radio" id="psych_no" name="psych" value="psych_no">'+
              '<label style="margin-left:0.5em" for="psych_no">No</label></p></div>',
  on_finish: function(data) {
    let psych = jsPsych.data.get().last(1).values()[0].responses;
    if (psych.includes("psych_yes")) {
      data.psych_neurdev = 1
    } else {
      data.psych_neurdev = 0
    }
  }
};

let psych_neurdev_condition= {
  conditional_function: function() {
      let psych_neurdev = jsPsych.data.get().last(1).values()[0].psych_neurdev;
      if (psych_neurdev) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.5em;line-height:1.25">What mental health or neurodevelopmental condition(s) have you been diagnosed with? Select all that apply.</p>'+
              '<div class="row-questions">'+
                '<div class="column-questions">'+            
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="mdd" name="psych" value="Major depressive disorder">'+
                      '<label style="margin-left:0.5em" for="mdd">Major depressive disorder (MDD)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="bpd" name="psych" value="Bipolar disorder">'+
                      '<label style="margin-left:0.5em" for="bpd">Bipolar disorder (BPD)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="gad" name="psych" value="Generalised anxiety disorder">'+
                      '<label style="margin-left:0.5em" for="gad">Generalised anxiety disorder</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="ocd" name="psych" value="Obsessive compulsive disorder">'+
                      '<label style="margin-left:0.5em" for="ocd">Obsessive compulsive disorder (OCD)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="anorex" name="psych" value="Anorexia nervosa">'+
                      '<label style="margin-left:0.5em" for="anorex">Anorexia nervosa</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="bulim" name="psych" value="Bulimia nervosa">'+
                      '<label style="margin-left:0.5em" for="bulim">Bulimia nervosa</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="social" name="psych" value="Social anxiety disorder">'+
                      '<label style="margin-left:0.5em" for="social">Social anxiety disorder</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="ptsd" name="psych" value="Post-traumatic stress disorder">'+
                      '<label style="margin-left:0.5em" for="ptsd">Post-traumatic stress disorder (PTSD)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="phobia" name="psych" value="Specific phobia">'+
                      '<label style="margin-left:0.5em" for="phobia">Specific phobia</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="scz" name="psych" value="Psychosis or schizoaffective disorder">'+
                      '<label style="margin-left:0.5em" for="scz">Psychosis or schizoaffective disorder</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="diss" name="psych" value="Dissociative identity disorder">'+
                      '<label style="margin-left:0.5em" for="diss">Dissociative identity disorder</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="subst" name="psych" value="Substance dependence or addictive disorder">'+
                      '<label style="margin-left:0.5em" for="subst">Substance dependence or addictive disorder</label>'+
                  '</p>'+         
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="personality" name="psych" value="Personality disorder">'+
                      '<label style="margin-left:0.5em" for="personality">Personality disorder</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="adhd" name="psych" value="Attention deficit/hyperactivity disorder">'+
                      '<label style="margin-left:0.5em" for="adhd">Attention deficit/hyperactivity disorder (ADHD)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="autism" name="psych" value="Autism">'+
                      '<label style="margin-left:0.5em" for="autism">Autism</label>'+
                  '</p>'+
                '</div>'+
              '</div>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="error" name="psych" value="None">'+
                  '<label style="margin-right:4em;margin-left:0.5em" for="error">No mental health or neurodevelopmental condition</label>'+
                '<input type="checkbox" id="other" name="psych" value="Other">'+
                  '<label style="margin-left:0.5em" for="other">Other (please specify)</label>'+
                '<input style="margin-left:1em;margin-bottom:2em" type="text" id="other_text" name="psych_text">'+
              '</p>',
        dataAsArray: true,
        checkbox_required: true,
        other_text_required: true,
        text_checkbox_pairs: [{checkbox_id: 'other', text_id: 'other_text', required_message: 'Please specify what other mental health or neurodevelopmental condition(s) you have been diagnosed with.'}],
        on_finish: function(data) {
          let psych_dis = jsPsych.data.get().last(1).values()[0].responses;
          if (psych_dis.includes("None")) {
            data.other_psych_neurdev_condition = "None";
            } else {
            let index = psych_dis.indexOf('psych_text')
            psych_dis = psych_dis.substring(0,index).replace("psych_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"psych,value:/g, "").replace(",name:\"",']');
            data.psych_neurdev_condition = psych_dis;            
            let other_dis_psy_text = jsPsych.data.get().last(1).values()[0].responses.replace(/\, /g,'__').replace(/\; /g,'__').replace(/ /g,'_').replace(/\W/g, '');
            other_dis_psy_text = other_dis_psy_text.substring(other_dis_psy_text.indexOf("psych_text")).replace("psych_text",'').replace("name",'').replace("value",'').replace(/\__/g, ", ").replace(/_/g, ' ');
            if (other_dis_psy_text != '') {
              data.other_psych_neurdev_condition = true
              data.other_psych_neurdev_condition_type = other_dis_psy_text;
            } else {
              data.other_psych_neurdev_condition = false
            }
          }
        }
      }
    ]
  };

let medication = {
  type: 'survey-html-form',
  html: '<div>'+
          '<p style="font-size:1.5em;line-height:1.25">Do you take any daily medication (e.g. an oral contraceptive or antidepressant)?</p>'+
          '<p style="font-size:1.25em">'+
            '<input type="radio" id="med_yes" name="med" value="med_yes" required>'+
              '<label style="margin-left:0.5em;margin-right:2em" for="med_yes">Yes</label>'+
            '<input type="radio" id="med_no" name="med" value="med_no">'+
              '<label style="margin-left:0.5em;" for="med_no">No</label>'+
          '</p>'+
        '</div>',
  data: {question: 'medication'},
  on_finish: function(data) {
    let med_any = jsPsych.data.get().last(1).values()[0].responses;
    if (med_any.includes("med_yes")) {
      data.medication = 1
    } else {
      data.medication = 0
    }
  }
};

let contraceptive = {
  conditional_function: function() {
      let medication = jsPsych.data.get().filter({question: 'medication'}).last(1).values()[0].medication;
      if (medication) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;line-height:1.25">Do you take an oral contraceptive (birth control pill)?</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="contra_yes" name="contra" value="contra_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="contra_yes">Yes</label>'+
                  '<input type="radio" id="contra_no" name="contra" value="contra_no">'+
                    '<label style="margin-left:0.5em;" for="contra_no">No</label>'+
                '</p>'+
              '</div>',
        on_finish: function(data) {
          let pill = jsPsych.data.get().last(1).values()[0].responses;
          if (pill.includes("contra_yes")) {
            data.contraceptive = 1
          } else {
            data.contraceptive = 0
          }
        }
      }
    ]
  };

  let antidepressant = {
  conditional_function: function() {
      let medication = jsPsych.data.get().filter({question: 'medication'}).last(1).values()[0].medication;
      if (medication) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;line-height:1.25">Do you take an antidepressant?</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="depr_yes" name="depr" value="depr_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="depr_yes">Yes</label>'+
                  '<input type="radio" id="depr_no" name="depr" value="depr_no">'+
                    '<label style="margin-left:0.5em;" for="depr_no">No</label>'+
                '</p>'+
              '</div>',
        on_finish: function(data) {
          let pill = jsPsych.data.get().last(1).values()[0].responses;
          if (pill.includes("depr_yes")) {
            data.antidepressant = 1
          } else {
            data.antidepressant = 0
          }
        }
      }
    ]
  };

let antidepressant_type = {
  conditional_function: function() {
      let antidepressant = jsPsych.data.get().last(1).values()[0].antidepressant;
      if (antidepressant) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.5em;line-height:1.25;padding-left:11em;padding-right:11em">Which of these antidepressants do you currently take?</p>'+
              '<div class="row-questions">'+
                '<div class="column-questions2">'+            
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="agomelatine" name="antidep" value="Agomelatine">'+
                      '<label style="margin-left:0.5em" for="agomelatine">Agomelatine (Valdoxan)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="amitriptyline" name="antidep" value="Amitriptyline">'+
                      '<label style="margin-left:0.5em" for="amitriptyline">Amitriptyline</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="citalopram" name="antidep" value="Citalopram">'+
                      '<label style="margin-left:0.5em" for="citalopram">Citalopram (Cipramil)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em"><input type="checkbox" id="clomipramine" name="antidep" value="Clomipramine">'+
                    '<label style="margin-left:0.5em" for="clomipramine">Clomipramine</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="dosulepin" name="antidep" value="Dosulepin">'+
                      '<label style="margin-left:0.5em" for="dosulepin">Dosulepin (Prothiaden)</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="doxepin" name="antidep" value="Doxepin">'+
                      '<label style="margin-left:0.5em" for="doxepin">Doxepin (Sinepin)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="duloxetine" name="antidep" value="Duloxetine">'+
                      '<label style="margin-left:0.5em" for="duloxetine">Duloxetine (Cymbalta)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="escitalopram" name="antidep" value="Escitalopram">'+
                      '<label style="margin-left:0.5em" for="escitalopram">Escitalopram (Cipralex)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em"><input type="checkbox" id="fluoxetine" name="antidep" value="Fluoxetine">'+
                    '<label style="margin-left:0.5em" for="fluoxetine">'+
                      '<span class="tooltip">Fluoxetine (Prozac)<span class="tooltiptext">Other names: Prozep, Olena, Oxactin</span></span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="fluvoxamine" name="antidep" value="Fluvoxamine">'+
                      '<label style="margin-left:0.5em" for="fluvoxamine">Fluvoxamine (Faverin)</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+            
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="imipramine" name="antidep" value="Imipramine">'+
                      '<label style="margin-left:0.5em" for="imipramine">Imipramine</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="lofepramine" name="antidep" value="Lofepramine">'+
                      '<label style="margin-left:0.5em" for="lofepramine">Lofepramine</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="mianserin" name="antidep" value="Mianserin">'+
                      '<label style="margin-left:0.5em" for="mianserin">Mianserin</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="mirtazapine" name="antidep" value="Mirtazapine">'+
                      '<label style="margin-left:0.5em" for="mirtazapine">Mirtazapine (Zispin)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="moclobemide" name="antidep" value="Moclobemide">'+
                      '<label style="margin-left:0.5em" for="moclobemide">Moclobemide (Manerix)</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="nortriptyline" name="antidep" value="Nortriptyline">'+
                      '<label style="margin-left:0.5em" for="nortriptyline">Nortriptyline (Allegron)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="paroxetine" name="antidep" value="Paroxetine">'+
                      '<label style="margin-left:0.5em" for="paroxetine">Paroxetine (Seroxat)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="phenelzine" name="antidep" value="Phenelzine">'+
                      '<label style="margin-left:0.5em" for="phenelzine">Phenelzine (Nardil)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="reboxetine" name="antidep" value="Reboxetine">'+
                      '<label style="margin-left:0.5em" for="reboxetine">Reboxetine (Edronax)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="sertraline" name="antidep" value="Sertraline">'+
                      '<label style="margin-left:0.5em" for="sertraline">Sertraline (Lustral)</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="tranylcypromine" name="antidep" value="Tranylcypromine">'+
                      '<label style="margin-left:0.5em" for="tranylcypromine">Tranylcypromine (Parnate)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="trazodone" name="antidep" value="Trazodone">'+
                      '<label style="margin-left:0.5em" for="trazodone">Trazodone (Molipaxin)</label>'+
                  '</p>'+         
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="trimipramine" name="antidep" value="Trimipramine">'+
                      '<label style="margin-left:0.5em" for="trimipramine">Trimipramine (Surmontil)</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em"><input type="checkbox" id="venlafaxine" name="antidep" value="Venlafaxine">'+
                    '<label style="margin-left:0.5em" for="venlafaxine">'+
                    '<span class="tooltip">Venlafaxine (Efexor XL)'+
                      '<span class="tooltiptext">Other names: Alventa XL, Amphero XL, Depefex XL, Foraven XL, Majoven XL, Politid XL, Sunveniz XL, '+
                        'Tonpular XL, Venaxx XL, Venlablue XL, Venladex XL, Venlalic XL, Venlasoz XL, Vensir XL, Venzip XL, ViePax XL</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:0.9em">'+
                    '<input type="checkbox" id="vortioxetine" name="antidep" value="Vortioxetine">'+
                      '<label style="margin-left:0.5em" for="vortioxetine">Vortioxetine (Brintellix)</label>'+
                  '</p>'+
                '</div>'+
              '</div>'+
              '<p style="font-size:0.9em">'+
                '<input type="checkbox" id="other" name="antidep" value="Other">'+
                  '<label style="margin-left:0.5em" for="other">Other (please specify)</label>'+
                '<input style="margin-left:0.5em;margin-bottom:2em" type="text" id="antidep_text" name="antidep_text">'+
              '</p>',
        dataAsArray: true,
        checkbox_required: true,
        other_text_required: true,
        text_checkbox_pairs: [{checkbox_id: 'other', text_id: 'antidep_text', required_message: 'Please specify what antidepressant(s) not on this list you are taking.'}],
        on_finish: function(data) {
          let antidep = jsPsych.data.get().last(1).values()[0].responses;
          let index = antidep.indexOf('antidep_text')
          antidep = antidep.substring(0,index).replace("antidep_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"antidep,value:/g, "").replace(",name:\"",']');
          data.antidepressant_type = antidep;            
          let antidep_other_text = jsPsych.data.get().last(1).values()[0].responses.replace(/\, /g,'__').replace(/\; /g,'__').replace(/ /g,'_').replace(/\W/g, '');
          antidep_other_text = antidep_other_text.substring(antidep_other_text.indexOf("antidep_text")).replace("antidep_text",'').replace("name",'').replace("value",'').replace(/\__/g, ", ").replace(/_/g, ' ');
          if (antidep_other_text != '') {
            data.other_antidepressant = true
            data.other_antidepressant_type = antidep_other_text;
          } else {
            data.other_antidepressant = false
          }
        }
      }
    ]
  };

let other_medication = {
  conditional_function: function() {
      let medication = jsPsych.data.get().filter({question: 'medication'}).last(1).values()[0].medication;
      if (medication) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;line-height:1.25;">Do you take any other daily medication?</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="othermed_yes" name="othermed" value="othermed_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="othermed_yes">Yes</label>'+
                  '<input type="radio" id="othermed_no" name="othermed" value="othermed_no">'+
                    '<label style="margin-left:0.5em;" for="othermed_no">No</label>'+
                '</p>'+
              '</div>',
        on_finish: function(data) {
          let other_meds = jsPsych.data.get().last(1).values()[0].responses;
          if (other_meds.includes("othermed_yes")) {
            data.other_medication = 1
          } else {
            data.other_medication = 0
          }
        }
      }
    ]
  }

let other_medication_type= {
  conditional_function: function() {
      let other_meds = jsPsych.data.get().last(1).values()[0].other_medication;
      if (other_meds) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.5em;line-height:1.25;padding-left:1em;padding-right:1em">What other daily medication do you take? Select all that apply.</p>'+
              '<div class="row-questions">'+
                '<div class="column-questions3">'+            
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="aht" name="othermed" value="Anti-hypertensive">'+
                    '<label style="margin-left:0.5em" for="aht">'+                      
                      '<span class="tooltip">Anti-hypertensive medication'+
                        '<span class="tooltiptext">e.g. Ramipril, losartan, amlodipine, beta blockers</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="painkill" name="othermed" value="Painkiller">'+
                    '<label style="margin-left:0.5em" for="painkill">'+
                      '<span class="tooltip">Painkiller'+
                        '<span class="tooltiptext">e.g. codeine, tramadol</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="antibiotic" name="othermed" value="Antibiotic">'+
                    '<label style="margin-left:0.5em" for="antibiotic">'+
                      '<span class="tooltip">Antibiotic'+
                        '<span class="tooltiptext">e.g. amoxillin, doxycycline</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="anticoag" name="othermed" value="Anticoagulant">'+
                    '<label style="margin-left:0.5em" for="anticoag">'+
                      '<span class="tooltip">Anticoagulant'+
                        '<span class="tooltiptext">e.g. Warfarin, Dabigatran, Apixaban</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="anticonv" name="othermed" value="Anticonvulsant">'+
                    '<label style="margin-left:0.5em" for="anticonv">'+
                      '<span class="tooltip">Anticonvulsant (anti-seizure medication)'+
                        '<span class="tooltiptext">e.g. gabapentin, lamotrigine</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions3">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="antianx" name="othermed" value="Anxiolytic">'+
                    '<label style="margin-left:0.5em" for="antianx">'+
                      '<span class="tooltip">Anti-anxiety or anxiolytic'+
                        '<span class="tooltiptext">e.g. propranolol, benzodiazepines</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="antiem" name="othermed" value="Antiemetic">'+
                    '<label style="margin-left:0.5em" for="antiem">'+
                      '<span class="tooltip">Anti-nausea or antiemetic'+
                        '<span class="tooltiptext">e.g. metoclopramide, cyclizine</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="antihypgly" name="othermed" value="Antihyperglycaemic">'+
                    '<label style="margin-left:0.5em" for="antihypgly">'+
                      '<span class="tooltip">Antihyperglycaemic'+
                        '<span class="tooltiptext">e.g. metformin, glipizide</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="statins" name="othermed" value="Statins">'+
                    '<label style="margin-left:0.5em" for="statins">'+
                      '<span class="tooltip">Statins'+
                        '<span class="tooltiptext">e.g. atorvastatin (Lipitor), simvastatin</span>'+
                      '</span>'+
                    '</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="supplem" name="othermed" value="Vitamin or supplement">'+
                      '<label style="margin-left:0.5em" for="supplem">Vitamin or supplement:</label>'+
                    '<input style="width:100px;margin-left:1em;" type="text" id="vitamin_text" name="othermed_vitamin_text">'+
                  '</p>'+
                '</div>'+
              '</div>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="other_med" name="othermed" value="Other medication">'+
                  '<label style="margin-left:0.5em" for="other_med">Other (please specify)</label>'+
                '<input style="width:100px;margin-left:1em;margin-bottom:2em" type="text" id="othermed_text" name="othermed_text">'+
              '</p>',
        dataAsArray: true,
        checkbox_required: true,
        other_text_required: true,
        text_checkbox_pairs: [
          {checkbox_id: 'supplem', text_id: 'vitamin_text', required_message: 'Please specify what vitamin(s) or supplement(s) you are taking.'},
          {checkbox_id: 'other_med', text_id: 'othermed_text', required_message: 'Please specify what other medication(s) not on this list you are taking.'}
        ],
        on_finish: function(data) {
          let other_meds = jsPsych.data.get().last(1).values()[0].responses;
          let index = other_meds.indexOf('othermed_vitamin_text')
          if (!other_meds.match("Other medication")) {
            other_meds = other_meds.substring(0,index).replace("othermed_vitamin_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"othermed,value:/g, "").replace(",name:\"",']');
          } else {
            other_meds = other_meds.substring(0,index).replace("othermed_vitamin_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"othermed,value:/g, "").replace(",name:\"",',"Other"]').replace("[name:\"", '[\"Other\"]');
          }
          data.other_medication_type = other_meds;
          let other_med_text = jsPsych.data.get().last(1).values()[0].responses.replace(/, /g,'__').replace(/; /g,'__').replace(/ /g,'_').replace(/\W/g, '');
          let other_med_other_text = other_med_text.substring(other_med_text.indexOf("othermed_text")).replace("othermed_text",'').replace("name",'').replace("value",'').replace(/__/g, ', ').replace(/_/g, ' ');
          let other_med_vitamin_text = other_med_text.substring(other_med_text.indexOf("othermed_vitamin_text"), other_med_text.indexOf("othermed_text")).replace(/othermed/gi,'').replace(/value/gi,'').replace("_vitamin_text",'');
          if (other_med_other_text != '' || other_med_text.includes("Other_medication")) {
            other_med_vitamin_text = other_med_vitamin_text.substring(0,other_med_vitamin_text.indexOf("name")).replace("name",'').replace(/__/g, ', ').replace(/_/g, ' ');
          } else {
            other_med_vitamin_text = other_med_vitamin_text.replace("name",'').replace(/__/g, ', ').replace(/_/g, ' ');
          }
          if (other_med_vitamin_text != '') {
            data.other_vitamin_supplement = true
            data.other_vitamin_supplement_text = other_med_vitamin_text;
          } else {
            data.other_vitamin_supplement = false
          }
          if (other_med_other_text != '') {
            data.other_medication_type_other = true
            data.other_medication_type_other_type = other_med_other_text;
          } else {
            data.other_medication_type_other = false
          }
        }
      }
    ]
  };

let periods = {
    type: 'survey-html-form',
    html: '<div>'+
            '<p style="font-size:1.5em;line-height:1.25">Do you have periods?</p>'+
            '<p style="font-size:1.25em">'+
              '<input type="radio" id="per_yes" name="period" value="per_yes" required>'+
                '<label style="margin-left:0.5em;margin-right:2em" for="per_yes">Yes</label>'+
              '<input type="radio" id="per_no" name="period" value="per_no">'+
                '<label style="margin-left:0.5em;" for="per_no">No</label>'+
            '</p>'+
          '</div>',
    on_finish: function(data) {
      let period = jsPsych.data.get().last(1).values()[0].responses;
      if (period.includes("per_yes")) {
        data.period = 1
      } else {
        data.period = 0
      }
    }
  };

let period_days = {
    conditional_function: function() {
      let periods = jsPsych.data.get().last(1).values()[0].period;
      if (periods) {
        return true
      } else {
          return false
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.5em;margin-right:1.5em">(Approximately) how many days have passed since the <strong><em>start</em></strong> of your last period?</p>'+
              '<p style="font-size:1.25em">'+
                '<input style="font-size:1em;width:2.15em;text-align:center;margin-left:0.5em;padding:5px" type="number" id="number" name="age" min="0" max="200" required>'+
                  '<label style="margin-left:0.5em" for="per_days">days</label>'+
              '</p>',
        on_finish: function(data) {
          let per_days = jsPsych.data.get().last(1).values()[0].responses.match(/[0-9]/g).join('');
          data.days_since_last_period = parseInt(per_days);
        }
      }
    ]
  };

let covid_current = {
    type: 'survey-html-form',
    html: '<div>'+
            '<p style="font-size:1.5em;line-height:1.25">Are you <strong><em>currently</em></strong> ill with probable COVID-19 (contracted in the last 3-4 weeks)?</p>'+
            '<p style="font-size:1.25em">'+
              '<input type="radio" id="cov_yes" name="covid" value="cov_yes" required>'+
                '<label style="margin-left:0.5em;margin-right:2em" for="cov_yes">Yes</label>'+
              '<input type="radio" id="cov_no" name="covid" value="cov_no">'+
                '<label style="margin-left:0.5em" for="cov_no">No</label>'+
            '</p>'+
          '</div>',
    data: {question: 'current_covid'},
    on_finish: function(data) {
      let covid_curr = jsPsych.data.get().last(1).values()[0].responses;
      if (covid_curr.includes("cov_yes")) {
        data.current_covid = 1
      } else {
        data.current_covid = 0
      }
    }
  };

let covid_diag = {
    conditional_function: function() {
      let current_covid = jsPsych.data.get().filter({question: 'current_covid'}).last(1).values()[0].current_covid;
      if (current_covid) {
        return false
      } else {
          return true
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;line-height:1.25">Have you <strong><em>ever</em></strong> been diagnosed by a doctor or other medical professional with COVID-19, '+
                  'or tested positive in a PCR or lateral flow test?'+
                '</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="covdiag_yes" name="diagcov" value="covdiag_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="covdiag_yes">Yes</label>'+
                  '<input type="radio" id="covdiag_no" name="diagcov" value="covdiag_no">'+
                    '<label style="margin-left:0.5em" for="covdiag_no">No</label>'+
                '</p>'+
              '</div>',
        data: {question: 'diagnosed_covid'},
        on_finish: function(data) {
          let covid_ever = jsPsych.data.get().last(1).values()[0].responses;
          if (covid_ever.includes("covdiag_yes")) {
            data.diagnosed_covid = 1
          } else {
            data.diagnosed_covid = 0
          }
        }
      }
    ]
  };

let covid_susp = {
    conditional_function: function() {
      let current_covid = jsPsych.data.get().filter({question: 'current_covid'}).last(1).values()[0].current_covid;
      let diagnosed_covid = jsPsych.data.get().last(1).values()[0].diagnosed_covid;
      if (current_covid || diagnosed_covid) {
        return false
      } else {
          return true
        }
      },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;line-height:1.25">Do you strongly suspect you have had COVID-19?</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="covever_sus_yes" name="covidever" value="covever_sus_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="covever_sus_yes">Yes</label>'+
                  '<input type="radio" id="covever_sus_no" name="covidever" value="covever_sus_no">'+
                    '<label style="margin-left:0.5em" for="covever_sus_no">No</label>'+
                '</p>'+
              '</div>',
        data: {question: 'suspected_covid'},
        on_finish: function(data) {
          let covid_ever = jsPsych.data.get().last(1).values()[0].responses;
          if (covid_ever.includes("covever_sus_yes")) {
            data.probable_covid = 1
          } else {
            data.probable_covid = 0
          }
        }
      }
    ]
  };


let long_covid = {
    conditional_function: function() {
      let curr = jsPsych.data.get().filter({question: 'current_covid'}).last(1).values()[0].current_covid;
      if (!curr) {
        let diag_covid = jsPsych.data.get().filter({question: 'diagnosed_covid'}).last(1).values()[0].diagnosed_covid;
        if (diag_covid) {
          return true
        } else if (!diag_covid) {
          let prob_covid = jsPsych.data.get().filter({question: 'suspected_covid'}).last(1).values()[0].probable_covid;
          if (prob_covid) {
            return true
          } else {
            return false
          }
        }
      } 
      else if (curr) {
        return false
      }
    },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<div>'+
                '<p style="font-size:1.5em;">Since the initial onset of your illness, have you been experiencing recurring or ongoing symptoms for <strong>12 weeks</strong> or more?</p>'+
                  '<p style="font-size:1.25em;margin-bottom:2em;">This is also known as long COVID, long-haul COVID, or post-COVID syndrome.</p>'+
                '<p style="font-size:1.25em">'+
                  '<input type="radio" id="longcov_yes" name="longcovid" value="longcov_yes" required>'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="longcov_yes">Yes</label>'+
                  '<input type="radio" id="longcov_maybe" name="longcovid" value="longcov_maybe">'+
                    '<label style="margin-left:0.5em;margin-right:2em" for="longcov_maybe">Maybe</label>'+
                  '<input type="radio" id="longcov_no" name="longcovid" value="longcov_no">'+
                    '<label style="margin-left:0.5em;" for="longcov_no">No</label>'+
                '</p>'+
              '</div>',
        data: {question: 'long_covid'},
        on_finish: function(data) {
          let longcov = jsPsych.data.get().last(1).values()[0].responses;
          if (longcov.includes("longcov_yes")) {
            data.long_covid = "Yes";
          } else if (longcov.includes("longcov_maybe")) {
            data.long_covid = "Maybe";
          } else {
            data.long_covid = "No";
          }
        }
      }
    ]
  };

let long_covid_symptoms = {
  conditional_function: function() {
      let curr = jsPsych.data.get().filter({question: 'current_covid'}).last(1).values()[0].current_covid;
      if (!curr) {
        let diag_covid = jsPsych.data.get().filter({question: 'diagnosed_covid'}).last(1).values()[0].diagnosed_covid;
        if (diag_covid) {
          let long_cov = jsPsych.data.get().filter({question: 'long_covid'}).last(1).values()[0].long_covid;
          if (long_cov != "No") {
            return true
          } else if (long_cov == "No") {
            return false
          }
        } else if (!diag_covid) {
          let prob_covid = jsPsych.data.get().filter({question: 'suspected_covid'}).last(1).values()[0].probable_covid;
          if (prob_covid) {
            let long_cov = jsPsych.data.get().filter({question: 'long_covid'}).last(1).values()[0].long_covid;
            if (long_cov != "No") {
              return true
            } else if (long_cov == "No") {
              return false
            }
          } else {
            return false
          }
        }
      } 
      else if (curr) {
        return false
      }
    },
    timeline: [
      {
        type: 'survey-html-form',
        html: '<p style="font-size:1.75em;line-height:1.25;">Are any of the following symptoms <strong><em>new</em></strong> or <strong><em>worse</em></strong>, compared with before you were ill?</p>'+
              '<p style="font-size:1.5em;line-height:1.25;">Please only select items that are new or have worsened since the onset of your COVID-19 symptoms.</p>'+
              '<div class="row-questions">'+
                '<div class="column-questions2">'+            
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="fatigue" name="symptom_covid" value="Fatigue">'+
                      '<label style="margin-left:0.5em" for="fatigue">Fatigue</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="muscle" name="symptom_covid" value="Muscle or body aches">'+
                      '<label style="margin-left:0.5em" for="muscle">Muscle or body aches</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="shortness" name="symptom_covid" value="Shortness of breath or difficulty breathing">'+
                      '<label style="margin-left:0.5em" for="shortness">Shortness of breath or difficulty breathing</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="concentration" name="symptom_covid" value="Difficulty concentrating or focusing">'+
                      '<label style="margin-left:0.5em" for="concentration">Difficulty concentrating or focusing</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="exercise" name="symptom_covid" value="Inability to exercise or be active">'+
                      '<label style="margin-left:0.5em" for="exercise">Inability to exercise or be active</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="headache" name="symptom_covid" value="Headache">'+
                      '<label style="margin-left:0.5em" for="headache">Headache</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="sleeping" name="symptom_covid" value="Difficulty sleeping">'+
                      '<label style="margin-left:0.5em" for="sleeping">Difficulty sleeping</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="anxiety" name="symptom_covid" value="Anxiety">'+
                      '<label style="margin-left:0.5em" for="anxiety">Anxiety</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="memory" name="symptom_covid" value="Memory problems">'+
                      '<label style="margin-left:0.5em" for="memory">Memory problems</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="dizzy" name="symptom_covid" value="Dizziness">'+
                      '<label style="margin-left:0.5em" for="dizzy">Dizziness</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="chest" name="symptom_covid" value="Persistent chest pain or pressure">'+
                      '<label style="margin-left:0.5em" for="chest">Persistent chest pain or pressure</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="cough" name="symptom_covid" value="Cough">'+
                      '<label style="margin-left:0.5em" for="cough">Cough</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="joints" name="symptom_covid" value="Joint pain">'+
                      '<label style="margin-left:0.5em" for="joints">Joint pain</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="heart" name="symptom_covid" value="Heart palpitations">'+
                      '<label style="margin-left:0.5em" for="heart">Heart palpitations</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="diarrhoea" name="symptom_covid" value="Diarrhoea">'+
                      '<label style="margin-left:0.5em" for="diarrhoea">Diarrhoea</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="throat" name="symptom_covid" value="Sore throat">'+
                      '<label style="margin-left:0.5em" for="throat">Sore throat</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="sweats" name="symptom_covid" value="Night sweats">'+
                      '<label style="margin-left:0.5em" for="sweats">Night sweats</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="smell" name="symptom_covid" value="Partial/complete loss of smell">'+
                      '<label style="margin-left:0.5em" for="smell">Partial/complete loss of smell</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="tachycardia" name="symptom_covid" value="Tachycardia (very fast resting heartbeat)">'+
                      '<label style="margin-left:0.5em" for="tachycardia">Tachycardia (very fast resting heartbeat)</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="fever" name="symptom_covid" value="Fever or chills">'+
                      '<label style="margin-left:0.5em" for="fever">Fever or chills</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="hairloss" name="symptom_covid" value="Hair loss">'+
                      '<label style="margin-left:0.5em" for="hairloss">Hair loss</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="blurry" name="symptom_covid" value="Blurry vision">'+
                      '<label style="margin-left:0.5em" for="blurry">Blurry vision</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="congestion" name="symptom_covid" value="Congested or runny nose">'+
                      '<label style="margin-left:0.5em" for="congestion">Congested or runny nose</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="sad" name="symptom_covid" value="Sadness">'+
                      '<label style="margin-left:0.5em" for="sad">Sadness</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="neuropathy" name="symptom_covid" value="Neuropathy (e.g. tingling, numbness) in feet and/or hands">'+
                      '<label style="margin-left:0.5em" for="neuropathy">Neuropathy (e.g. tingling, numbness) in feet/hands</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="reflux" name="symptom_covid" value="Acid reflux or heartburn">'+
                      '<label style="margin-left:0.5em" for="reflux">Acid reflux or heartburn</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="changing" name="symptom_covid" value="Changing symptoms">'+
                      '<label style="margin-left:0.5em" for="changing">Changing symptoms</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="taste" name="symptom_covid" value="Partial/complete loss of taste">'+
                      '<label style="margin-left:0.5em" for="taste">Partial/complete loss of taste</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="phlegm" name="symptom_covid" value="Phlegm in back of throat">'+
                      '<label style="margin-left:0.5em" for="phlegm">Phlegm in back of throat</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="abdominal" name="symptom_covid" value="Abdominal pain">'+
                      '<label style="margin-left:0.5em" for="abdominal">Abdominal pain</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="lower_back" name="symptom_covid" value="Lower back pain">'+
                      '<label style="margin-left:0.5em" for="lower_back">Lower back pain</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="shortness_bend" name="symptom_covid" value="Shortness of breath or exhaustion from bending over">'+
                      '<label style="margin-left:0.5em" for="shortness_bend">Shortness of breath/exhaustion from bending over</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="nausea" name="symptom_covid" value="Nausea or vomiting">'+
                      '<label style="margin-left:0.5em" for="nausea">Nausea or vomiting</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="weight" name="symptom_covid" value="Weight gain">'+
                      '<label style="margin-left:0.5em" for="weight">Weight gain</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="clogged" name="symptom_covid" value="Clogged ears">'+
                      '<label style="margin-left:0.5em" for="clogged">Clogged ears</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="dryeyes" name="symptom_covid" value="Dry eyes">'+
                      '<label style="margin-left:0.5em" for="dryeyes">Dry eyes</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="calf" name="symptom_covid" value="Calf cramps">'+
                      '<label style="margin-left:0.5em" for="calf">Calf cramps</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="tremors" name="symptom_covid" value="Tremors or shakiness">'+
                      '<label style="margin-left:0.5em" for="tremors">Tremors or shakiness</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="sleeping_more" name="symptom_covid" value="Sleeping more than normal">'+
                      '<label style="margin-left:0.5em" for="sleeping_more">Sleeping more than normal</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="upper_back" name="symptom_covid" value="Upper back pain">'+
                      '<label style="margin-left:0.5em" for="upper_back">Upper back pain</label>'+
                  '</p>'+
                '</div>'+
                '<div class="column-questions2">'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="flash" name="symptom_covid" value="Floaters or flashes of light in vision">'+
                      '<label style="margin-left:0.5em" for="flash">Floaters or flashes of light in vision</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="rash" name="symptom_covid" value="Rash">'+
                      '<label style="margin-left:0.5em" for="rash">Rash</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="thirst" name="symptom_covid" value="Constant thirst">'+
                      '<label style="margin-left:0.5em" for="thirst">Constant thirst</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="nerves" name="symptom_covid" value="Nerve sensations">'+
                      '<label style="margin-left:0.5em" for="nerves">Nerve sensations</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="tinnitus" name="symptom_covid" value="Tinnitus or humming in ears">'+
                      '<label style="margin-left:0.5em" for="tinnitus">Tinnitus or humming in ears</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="change_taste" name="symptom_covid" value="Changed sense of taste">'+
                      '<label style="margin-left:0.5em" for="change_taste">Changed sense of taste</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="sharp_chest" name="symptom_covid" value="Sharp or sudden chest pain">'+
                      '<label style="margin-left:0.5em" for="sharp_chest">Sharp or sudden chest pain</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="confusion" name="symptom_covid" value="Confusion">'+
                      '<label style="margin-left:0.5em" for="confusion">Confusion</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="twitch" name="symptom_covid" value="Muscle twitching">'+
                      '<label style="margin-left:0.5em" for="twitch">Muscle twitching</label>'+
                  '</p>'+
                  '<p style="font-size:1em">'+
                    '<input type="checkbox" id="irritable" name="symptom_covid" value="Feeling irritable">'+
                      '<label style="margin-left:0.5em" for="irritable">Feeling irritable</label>'+
                  '</p>'+
                '</div>'+
              '</div>'+
              '<p style="font-size:1em">'+
                '<input type="checkbox" id="no_symptoms" name="symptom_covid" value="None of the above">'+
                  '<label style="margin-left:0.5em;margin-right:4em" for="no_symptoms">No symptoms are worse than before</label>'+
                '<input type="checkbox" id="other" name="symptom_covid" value="Other symptom">'+
                  '<label style="margin-left:0.5em" for="other">Other symptom(s) (please specify)</label>'+
                '<input style="margin-left:0.5em;margin-bottom:1em" type="text" id="other_text" name="covid_text">'+
              '</p>',
        checkbox_required: true,
        dataAsArray: true,
        other_text_required: true,
        text_checkbox_pairs: [{checkbox_id: 'other', text_id: 'other_text', required_message: 'Please specify what other symptom(s) not on this list that have worsened.'}],
        on_finish: function(data) {
          let symptoms = jsPsych.data.get().last(1).values()[0].responses;
          if (symptoms.includes("None of the above")) {
            data.long_covid_symptoms = "None";
          } else {
            let index = symptoms.indexOf('covid_text')
            symptoms = symptoms.substring(0,index).replace("covid_text",'').replace(/[\"\{]/g, '').replace(/\:/g, "\:\"").replace(/\}/g, "\"").replace(/name:\"symptom_covid,value:/g, "").replace(",name:\"",']');
            data.long_covid_symptoms = symptoms;            
            let long_covid_other_symptom_text = jsPsych.data.get().last(1).values()[0].responses.replace(/, /g,'__').replace(/; /g,'__').replace(/ /g,'_').replace(/\W/g, '');
            long_covid_other_symptom_text = long_covid_other_symptom_text.substring(long_covid_other_symptom_text.indexOf("covid_text")).replace("covid_text",'').replace("name",'').replace("value",'').replace(/__/g, ', ').replace(/_/g, ' ');
            if (long_covid_other_symptom_text != '') {
              data.other_long_covid_symptom = true
              data.other_long_covid_symptom_type = long_covid_other_symptom_text;
            } else {
              data.other_long_covid_symptom = false
            }
          }
        }
      }
    ]
  };

let finish = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;color:#9ee09e;line-height:1">'+
              '<p><h2>Thank you! You have completed the demographic survey.</p></h2>'+
            '</div>'+
            '<div style="font-size:1.5em;color:#6B6D8C;max-width:1300px;line-height:1.5">'+
              '<p>From this point, you will be unable to restart the experiment, so please avoid reloading your browser. Press <strong>Next</strong> to proceed to the main task.</p>'+
            '</div>',
  choices: ['Next']
}

timeline.push(welcome, init_message, consent, consent2, disclaimer, take_part, stop_leave, instructions, age, gender, ethnicity, ses, income, english, japanese, neurological, neurological_disorder, 
psych_neurdev, psych_neurdev_condition, medication, contraceptive, antidepressant, antidepressant_type, other_medication, other_medication_type, periods, period_days, covid_current, covid_diag, 
covid_susp, long_covid, long_covid_symptoms, finish);

/* start the experiment */
jatos.onLoad(function () {
  prolific_id = jatos.urlQueryParameters.PROLIFIC_PID;
  study_id = jatos.urlQueryParameters.STUDY_ID;
  session_id = jatos.urlQueryParameters.SESSION_ID;
  jsPsych.data.addProperties({prolific_id: prolific_id, study_id: study_id, session_id: session_id});
  jsPsych.init({
    timeline: timeline,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.submitResultData(trialsJson, jatos.startNextComponent); 
    }
  });
});
/*
* Questionnaire questions
*/

let timeline = []

let instructions = {
  type: 'instructions',
  pages: ["<div style='font-size:1.75em;line-height:1.25;max-width:1440px;'>"+
          "<p>The final part of the experiment comprises a number of items from different questionnaires, covering a range of topics.</p></div>",
          "<div style='font-size:1.5em;line-height:1.25;max-width:1600px;'>"+
            "<p>For each group of questions, you will first receive specific instructions on how to answer them: please read these carefully!</p>"+
            "<p>You should also pay close attention to the option labels, as these are different for each of the groups of questions. "+
              "Read each question or statement, and then answer as honestly as you can, but don't take too long over any one answer.</p>"+
            "<p>Press <em>Next</em> to proceed.</p>"+
          "</div>"
          ],
  show_clickable_nav: true,
  allow_keys: false,
  show_page_number: true,
  button_label_previous: 'Prev'
};

let disclaimer = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.25em;line-height:1.5;max-width:1440px;">'+
              '<h2 style="font-size:1.5em;margin-bottom:1em;text-align:center;line-height:1.25">Disclaimer</h2>'+
              '<p>This is a reminder that in the following section you will be asked questions regarding your mental and physical health. We understand that sometimes answering these questions '+
                'can make people aware of problems that they may be having with their health. If you do have any concerns about your health, please contact your '+
                'your GP, who can direct you to the appropriate local clinical service.</p>'+
            '</div>',
  choices: ['I understand']
};

let zung_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>For the following statements, please choose the option that best describes how you have been feeling or behaving <strong>over the past several days</strong>.</p>'+
            '</div>',
  choices: ['Continue']
};

let zung_choices = [
  'A little of the time',
  'Some of the time',
  'Good part of the time',
  'Most of the time'
];

let zung_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>Over the past several days...</em>',
      data: {
        reversed_scoring: jsPsych.timelineVariable('reversed'),
        questionnaire: 'ZDS', 
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '900',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let reversed = jsPsych.data.get().last(1).values()[0].reversed_scoring;
        let no_ZDS_qs = jsPsych.data.get().filter({questionnaire: 'ZDS'}).count();
        score_raw = parseInt(score_str)+1;
        if (reversed) {
          data.score = 5-score_raw;
        } else {
          data.score = score_raw;
        }
        if (no_ZDS_qs==8) {
          data.ZDS_total = jsPsych.data.get().filter({questionnaire: 'ZDS'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I feel down-hearted and blue.', labels: zung_choices, name: 'zung_one', required: true}, reversed: false,  survey_question_no: 1, gillan_name: 'SDS_1', gillan_item_no: 116},
    {question: 
      {prompt: 'My mind is as clear as it used to be.', labels: zung_choices, name: 'zung_two', required: true}, reversed: true, survey_question_no: 11, gillan_name: 'SDS_11', gillan_item_no: 126},
    {question: 
      {prompt: 'I find it easy to do the things I used to do.', labels: zung_choices, name: 'zung_three', required: true}, reversed: true,  survey_question_no: 12, gillan_name: 'SDS_12', gillan_item_no: 127},
    {question: 
      {prompt: 'I feel hopeful about the future.', labels: zung_choices, name: 'zung_four', required: true}, reversed: true,  survey_question_no: 14, gillan_name: 'SDS_14', gillan_item_no: 129},
    {question: 
      {prompt: 'I find it easy to make decisions.', labels: zung_choices, name: 'zung_five', required: true}, reversed: true,  survey_question_no: 16, gillan_name: 'SDS_16', gillan_item_no: 131},
    {question: 
      {prompt: 'I feel that I am useful and needed.', labels: zung_choices, name: 'zung_six', required: true}, reversed: true,  survey_question_no: 17, gillan_name: 'SDS_17', gillan_item_no: 132},
    {question: 
      {prompt: 'My life is pretty full.', labels: zung_choices, name: 'zung_seven', required: true}, reversed: true, survey_question_no: 18, gillan_name: 'SDS_18', gillan_item_no: 133},
    {question: 
      {prompt: 'I still enjoy the things I used to do.', labels: zung_choices, name: 'zung_eight', required: true}, reversed: true,  survey_question_no: 20, gillan_name: 'SDS_20', gillan_item_no: 135}
  ]
};

let ocir_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following statements refer to experiences that many people have in their everyday lives.</p>'+
              '<p>Please choose the option that best describes how much that experience has '+
                '<em>distressed</em> or <em>bothered</em> you <strong>during the past month</strong>.</p>'+
            '</div>',
  choices: ['Continue']
  };

let ocir_choices = [
  'Not at all',
  'A little',
  'Moderately',
  'A lot',
  'Extremely'
];

let ocir_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>During the past month...</em>',
      data: {
        questionnaire: 'OCIR',
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_OCIR_qs = jsPsych.data.get().filter({questionnaire: 'OCIR'}).count();
        data.score = parseInt(score_str);
        if (no_OCIR_qs==15) { // 14 in 70-question version
          data.OCIR_total = jsPsych.data.get().filter({questionnaire: 'OCIR'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I check things more often than necessary.', labels: ocir_choices, name: 'ocir_one', required: true}, survey_question_no: 2, gillan_name: 'OCI_2', gillan_item_no: 45},
    {question: 
      {prompt: 'I get upset if objects are not arranged properly.', labels: ocir_choices, name: 'ocir_two', required: true}, survey_question_no: 3, gillan_name: 'OCI_3', gillan_item_no: 46},
    {question: 
      {prompt: 'I feel compelled to count while I am doing things.', labels: ocir_choices, name: 'ocir_three', required: true}, survey_question_no: 4, gillan_name: 'OCI_4', gillan_item_no: 47},
    {question: 
      {prompt: 'I find it difficult to touch an object when I know it has been touched by strangers or certain people.', labels: ocir_choices, name: 'ocir_four', required: true}, survey_question_no: 5, gillan_name: 'OCI_5', gillan_item_no: 48},
    {question: 
      {prompt: 'I find it difficult to control my own thoughts.', labels: ocir_choices, name: 'ocir_five', required: true}, survey_question_no: 6, gillan_name: 'OCI_6', gillan_item_no: 49},
    {question: 
      {prompt: 'I collect things I don\'t need.', labels: ocir_choices, name: 'ocir_six', required: true},  survey_question_no: 7, gillan_name: 'OCI_7', gillan_item_no: 50},
    {question: 
      {prompt: 'I repeatedly check doors, windows, drawers, etc.', labels: ocir_choices, name: 'ocir_seven', required: true},  survey_question_no: 8, gillan_name: 'OCI_8', gillan_item_no: 51},
    {question: 
      {prompt: 'I get upset if others change the way I have arranged things.', labels: ocir_choices, name: 'ocir_eight', required: true}, survey_question_no: 9, gillan_name: 'OCI_9', gillan_item_no: 52},
    {question: 
      {prompt: 'I sometimes have to wash or clean myself simply because I feel contaminated.', labels: ocir_choices, name: 'ocir_nine', required: true}, survey_question_no: 11, gillan_name: 'OCI_11', gillan_item_no: 54},
    {question: 
      {prompt: 'I am upset by unpleasant thoughts that come into my mind against my will.', labels: ocir_choices, name: 'ocir_ten', required: true}, survey_question_no: 12, gillan_name: 'OCI_12', gillan_item_no: 55},
    {question: 
      {prompt: 'I avoid throwing things away because I am afraid I might need them later.', labels: ocir_choices, name: 'ocir_eleven', required: true}, survey_question_no: 13, gillan_name: 'OCI_13', gillan_item_no: 56},
    {question: 
      {prompt: 'I repeatedly check gas and water taps and light switches after turning them off.', labels: ocir_choices, name: 'ocir_twelve', required: true}, survey_question_no: 14, gillan_name: 'OCI_14', gillan_item_no: 57}, // not in 70
    {question: 
      {prompt: 'I need things to be arranged in a particular way.', labels: ocir_choices, name: 'ocir_thirteen', required: true}, survey_question_no: 15, gillan_name: 'OCI_15', gillan_item_no: 58},
    {question: 
      {prompt: 'I feel that there are good and bad numbers.', labels: ocir_choices, name: 'ocir_fourteen', required: true}, survey_question_no: 16, gillan_name: 'OCI_16', gillan_item_no: 59},
    {question: 
      {prompt: 'I frequently get nasty thoughts and have difficulty in getting rid of them.', labels: ocir_choices, name: 'ocir_fifteen', required: true}, survey_question_no: 18, gillan_name: 'OCI_18', gillan_item_no: 61}
  ]
};

let lsas_fear_instructions = {
    type: 'instructions',
    pages: ['<div style="font-size:1.5em;line-height:1.5;max-width:1600px;"'+
            '<p>The following statements contain a variety of social situations that you may have found yourself in.</p>'+
            '<p>For these statements, please select the option that best describes the level of <strong>fear</strong> you have for these situations, based on how you have '+
              'felt in the <strong>past week</strong>.</p>'+
            '</div>',
            '<div style="font-size:1.5em;line-height:1.5;max-width:1600px;"'+
              '<p>If you come across a situation that you have not experienced, please try to imagine how you would feel if faced with this hypothetical situation, and rate '+
                'how <strong>fearful</strong> you expect you would be based on how you have felt in the past week.</p>'+
              '<p>In addition, if you are restricted from these activities for an external reason (e.g. a COVID-related lockdown) try to imagine your behaviour '+
                'if there were no current restrictions based on how you have felt in the past week.</p>'+
              '<p>Press <em>Next</em> to proceed.</p>'+
            '</div>'
            ],
    show_clickable_nav: true,
    allow_keys: false,
    show_page_number: true,
    button_label_previous: 'Prev'
  };

let lsas_fear_choices = [
  'None',
  'Mild',
  'Moderate',
  'Severe'
];

let lsas_fear_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>In the past week, what level of fear have you (or would you have) had for...</em>',
      data: {
        questionnaire: 'LSAS_F',
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '600',
      font_size: [
        {statement: '1.5em', response: '1.25em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_LSAS_qs = jsPsych.data.get().filter({questionnaire: 'LSAS_F'}).count();
        data.score_raw = parseInt(score_str);
        data.score = parseInt(score_str)/2; // will be averaged
        if (no_LSAS_qs==16) { // 15 in 70-question version
          data.LSAS_fear_total = jsPsych.data.get().filter({questionnaire: 'LSAS_F'}).select('score_raw').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'Participating in small groups.', labels: lsas_fear_choices, name: 'lsasf_one', required: true}, survey_question_no: 2, gillan_name: 'LSAS_2', gillan_item_no: 187}, // not in 70
    {question: 
      {prompt: 'Acting, performing or giving a talk in front of an audience.', labels: lsas_fear_choices, name: 'lsasf_two', required: true}, survey_question_no: 6, gillan_name: 'LSAS_6', gillan_item_no: 191},
    {question: 
      {prompt: 'Going to a party.', labels: lsas_fear_choices, name: 'lsasf_three', required: true}, survey_question_no: 7, gillan_name: 'LSAS_7', gillan_item_no: 192},
    {question: 
      {prompt: 'Working while being observed.', labels: lsas_fear_choices, name: 'lsasf_four', required: true}, survey_question_no: 8, gillan_name: 'LSAS_8', gillan_item_no: 193},
    {question: 
      {prompt: 'Writing while being observed.', labels: lsas_fear_choices, name: 'lsasf_five', required: true}, survey_question_no: 9, gillan_name: 'LSAS_9', gillan_item_no: 194},
    {question: 
      {prompt: 'Calling someone you don\'t know very well.', labels: lsas_fear_choices, name: 'lsasf_six', required: true}, survey_question_no: 10, gillan_name: 'LSAS_10', gillan_item_no: 195},
    {question: 
      {prompt: 'Talking with people you don\'t know very well.', labels: lsas_fear_choices, name: 'lsasf_seven', required: true},  survey_question_no: 11, gillan_name: 'LSAS_11', gillan_item_no: 196},
    {question: 
      {prompt: 'Meeting strangers.', labels: lsas_fear_choices, name: 'lsasf_eight', required: true}, survey_question_no: 12, gillan_name: 'LSAS_12', gillan_item_no: 197},
    {question: 
      {prompt: 'Being the centre of attention.', labels: lsas_fear_choices, name: 'lsasf_nine', required: true}, survey_question_no: 15, gillan_name: 'LSAS_15', gillan_item_no: 200},
    {question: 
      {prompt: 'Speaking up at a meeting.', labels: lsas_fear_choices, name: 'lsasf_ten', required: true}, survey_question_no: 16, gillan_name: 'LSAS_16', gillan_item_no: 201},
    {question: 
      {prompt: 'Expressing a disagreement or disapproval to people you don\'t know very well.', labels: lsas_fear_choices, name: 'lsasf_eleven', required: true}, survey_question_no: 18, gillan_name: 'LSAS_18', gillan_item_no: 203},
    {question: 
      {prompt: 'Looking at people you don’t know very well in the eyes.', labels: lsas_fear_choices, name: 'lsasf_twelve', required: true}, survey_question_no: 19, gillan_name: 'LSAS_19', gillan_item_no: 204},
    {question: 
      {prompt: 'Giving a report to a group.', labels: lsas_fear_choices, name: 'lsasf_thirteen', required: true}, survey_question_no: 20, gillan_name: 'LSAS_20', gillan_item_no: 205},
    {question: 
      {prompt: 'Trying to pick up someone (in the sense of starting a romantic/sexual relationship with them).', labels: lsas_fear_choices, name: 'lsasf_fourteen', required: true}, survey_question_no: 21, gillan_name: 'LSAS_21', gillan_item_no: 206},
    {question: 
      {prompt: 'Giving a party.', labels: lsas_fear_choices, name: 'lsasf_fifteen', required: true}, survey_question_no: 23, gillan_name: 'LSAS_23', gillan_item_no: 208},
    {question: 
      {prompt: 'Resisting a high pressure salesperson.', labels: lsas_fear_choices, name: 'lsasf_sixteen', required: true}, survey_question_no: 24, gillan_name: 'LSAS_24', gillan_item_no: 209}
  ]
};

let lsas_avoid_instructions = {
    type: 'instructions',
    pages: ['<div style="font-size:1.5em;line-height:1.5;max-width:1600px;"'+
            '<p>The following statements are the same as in the previous section, and refer to a number of social situations you may have found yourself in.</p>'+
            '<p>However, for these statements, please select the option that best describes how much you would <strong>avoid</strong> these situations, based on how you have '+
              'felt in the <strong>past week</strong>.</p>'+
            '</div>',
            '<div style="font-size:1.5em;line-height:1.5;max-width:1600px;"'+
              '<p>If you come across a situation that you have not experienced, or are restricted from at the moment, please try to imagine how likely you would be to <strong>avoid</strong> '+
                'this hypothetical situation based on how you have felt in the past week.</p>'+
              '<p>Press <em>Next</em> to proceed.</p>'+
            '</div>'
            ],
    show_clickable_nav: true,
    allow_keys: false,
    show_page_number: true,
    button_label_previous: 'Prev'
};

let lsas_avoid_choices = [
  'Never (0%)',
  'Occasionally (1-33%)',
  'Often (34-66%)',
  'Usually (67-100%)'
];

let lsas_avoid_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      data: {
        questionnaire: jsPsych.timelineVariable('questionnaire'),
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      preamble: '<em>In the past week, I (would have) avoided...</em>',
      scale_width: '800',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let catch_question = jsPsych.data.get().last(1).values()[0].questionnaire == 'catch_questions';
        if (catch_question) {
          let score = parseInt(score_str);
          data.catch_question_pass = score == 3;
        } else {
          let no_LSAS_qs = jsPsych.data.get().filter({questionnaire: 'LSAS_A'}).count();
          data.score_raw = parseInt(score_str);
          data.score = parseInt(score_str)/2; // will be averaged
          if (no_LSAS_qs==16) { // 15 in 70-question version
            data.LSAS_avoidance_total = jsPsych.data.get().filter({questionnaire: 'LSAS_A'}).select('score_raw').sum();
          }
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'Participating in small groups.', labels: lsas_avoid_choices, name: 'lsasa_one', required: true}, questionnaire: 'LSAS_A', survey_question_no: 2, gillan_name: 'LSAS_2', gillan_item_no: 187}, // not in 70
    {question: 
      {prompt: 'Acting, performing or giving a talk in front of an audience.', labels: lsas_avoid_choices, name: 'lsasa_two', required: true}, questionnaire: 'LSAS_A', survey_question_no: 6, gillan_name: 'LSAS_6', gillan_item_no: 191},
    {question: 
      {prompt: 'Going to a party.', labels: lsas_avoid_choices, name: 'lsasa_three', required: true}, questionnaire: 'LSAS_A', survey_question_no: 7, gillan_name: 'LSAS_7', gillan_item_no: 192},
    {question: 
      {prompt: 'Working while being observed.', labels: lsas_avoid_choices, name: 'lsasa_four', required: true}, questionnaire: 'LSAS_A', survey_question_no: 8, gillan_name: 'LSAS_8', gillan_item_no: 193},
    {question: 
      {prompt: 'Eating mouldy food.', labels: lsas_avoid_choices, name: 'catch_question', required: true}, questionnaire: 'catch_questions', survey_question_no: 3},
    {question: 
      {prompt: 'Writing while being observed.', labels: lsas_avoid_choices, name: 'lsasa_five', required: true}, questionnaire: 'LSAS_A', survey_question_no: 9, gillan_name: 'LSAS_9', gillan_item_no: 194},
    {question: 
      {prompt: 'Calling someone you don\'t know very well.', labels: lsas_avoid_choices, name: 'lsasa_six', required: true}, questionnaire: 'LSAS_A', survey_question_no: 10, gillan_name: 'LSAS_10', gillan_item_no: 195},
    {question: 
      {prompt: 'Talking with people you don\'t know very well.', labels: lsas_avoid_choices, name: 'lsasa_seven', required: true},  questionnaire: 'LSAS_A', survey_question_no: 11, gillan_name: 'LSAS_11', gillan_item_no: 196},
    {question: 
      {prompt: 'Meeting strangers.', labels: lsas_avoid_choices, name: 'lsasa_eight', required: true}, questionnaire: 'LSAS_A', survey_question_no: 12, gillan_name: 'LSAS_12', gillan_item_no: 197},
    {question: 
      {prompt: 'Being the centre of attention.', labels: lsas_avoid_choices, name: 'lsasa_nine', required: true}, questionnaire: 'LSAS_A', survey_question_no: 15, gillan_name: 'LSAS_15', gillan_item_no: 200},
    {question: 
      {prompt: 'Speaking up at a meeting.', labels: lsas_avoid_choices, name: 'lsasa_ten', required: true}, questionnaire: 'LSAS_A', survey_question_no: 16, gillan_name: 'LSAS_16', gillan_item_no: 201},
    {question: 
      {prompt: 'Expressing a disagreement or disapproval to people you don\'t know very well.', labels: lsas_avoid_choices, name: 'lsasa_eleven', required: true}, questionnaire: 'LSAS_A', survey_question_no: 18, gillan_name: 'LSAS_18', gillan_item_no: 203},
    {question: 
      {prompt: 'Looking at people you don’t know very well in the eyes.', labels: lsas_avoid_choices, name: 'lsasa_twelve', required: true}, questionnaire: 'LSAS_A', survey_question_no: 19, gillan_name: 'LSAS_19', gillan_item_no: 204},
    {question: 
      {prompt: 'Giving a report to a group.', labels: lsas_avoid_choices, name: 'lsasa_thirteen', required: true}, questionnaire: 'LSAS_A', survey_question_no: 20, gillan_name: 'LSAS_20', gillan_item_no: 205},
    {question: 
      {prompt: 'Trying to pick up someone (in the sense of starting a romantic/sexual relationship with them).', labels: lsas_avoid_choices, name: 'lsasa_fourteen', required: true}, questionnaire: 'LSAS_A', survey_question_no: 21, gillan_name: 'LSAS_21', gillan_item_no: 206},
    {question: 
      {prompt: 'Giving a party.', labels: lsas_avoid_choices, name: 'lsasa_fifteen', required: true}, questionnaire: 'LSAS_A', survey_question_no: 23, gillan_name: 'LSAS_23', gillan_item_no: 208},
    {question: 
      {prompt: 'Resisting a high pressure salesperson.', labels: lsas_avoid_choices, name: 'lsasa_sixteen', required: true}, questionnaire: 'LSAS_A', survey_question_no: 24, gillan_name: 'LSAS_24', gillan_item_no: 209}
  ]
};

let eat_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following questions are intended to capture your attitudes to eating.</p>'+
              '<p>For each of the following statements, please select the option that best describes <strong>how often</strong> you feel that way.</p>'+
            '</div>',
  choices: ['Continue']
  };

let eat_choices = [    
  'Never',
  'Rarely',
  'Sometimes',
  'Often',
  'Usually',
  'Always'
];

let eat_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      data: {
        questionnaire: 'EAT',
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '800',
      font_size: [
        {statement: '1.5em', response: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-5]/g);
        let no_EAT_qs = jsPsych.data.get().filter({questionnaire: 'EAT'}).count();
        data.score = parseInt(score_str);
        if (no_EAT_qs==18) { // 16 in 70-question version
          data.EAT_total = jsPsych.data.get().filter({questionnaire: 'EAT'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I am terrified about being overweight.', labels: eat_choices, name: 'eat_one', required: true}, survey_question_no: 1, gillan_name: 'EAT_1', gillan_item_no: 62},
    {question: 
      {prompt: 'I avoid eating when I am hungry.', labels: eat_choices, name: 'eat_two', required: true}, survey_question_no: 2, gillan_name: 'EAT_2', gillan_item_no: 63}, // not in 70
    {question: 
      {prompt: 'I find myself preoccupied with food.', labels: eat_choices, name: 'eat_three', required: true}, survey_question_no: 3, gillan_name: 'EAT_3', gillan_item_no: 64},
    {question: 
      {prompt: 'I have gone on eating binges where I feel that I may not be able to stop.', labels: eat_choices, name: 'eat_four', required: true}, survey_question_no: 4, gillan_name: 'EAT_4', gillan_item_no: 65},
    {question: 
      {prompt: 'I am aware of the calorie content of foods I eat.', labels: eat_choices, name: 'eat_five', required: true}, survey_question_no: 6, gillan_name: 'EAT_6', gillan_item_no: 67}, // not in 70
    {question: 
      {prompt: 'I particularly avoid food with a high carbohydrate content (i.e. bread, rice, potatoes, etc).', labels: eat_choices, name: 'eat_six', required: true}, survey_question_no: 7, gillan_name: 'EAT_7', gillan_item_no: 68},
    {question: 
      {prompt: 'I feel that others would prefer if I ate more.', labels: eat_choices, name: 'eat_seven', required: true}, survey_question_no: 8, gillan_name: 'EAT_8', gillan_item_no: 69},
    {question: 
      {prompt: 'I feel extremely guilty after eating.', labels: eat_choices, name: 'eat_eight', required: true}, survey_question_no: 10, gillan_name: 'EAT_10', gillan_item_no: 71},
    {question: 
      {prompt: 'I am preoccupied with a desire to be thinner.', labels: eat_choices, name: 'eat_nine', required: true}, survey_question_no: 11, gillan_name: 'EAT_11', gillan_item_no: 72},
    {question: 
      {prompt: 'I think about burning up calories when I exercise.', labels: eat_choices, name: 'eat_ten', required: true}, survey_question_no: 12, gillan_name: 'EAT_12', gillan_item_no: 73},
    {question: 
      {prompt: 'I am preoccupied with the thought of having fat on my body.', labels: eat_choices, name: 'eat_eleven', required: true}, survey_question_no: 14, gillan_name: 'EAT_14', gillan_item_no: 74},
    {question: 
      {prompt: 'I take longer than others to eat meals.', labels: eat_choices, name: 'eat_twelve', required: true}, survey_question_no: 15, gillan_name: 'EAT_15', gillan_item_no: 75},
    {question: 
      {prompt: 'I feel that food controls my life.', labels: eat_choices, name: 'eat_thirteen', required: true}, survey_question_no: 18, gillan_name: 'EAT_18', gillan_item_no: 79},
    {question: 
      {prompt: 'I feel that others pressure me to eat.', labels: eat_choices, name: 'eat_fourteen', required: true}, survey_question_no: 20, gillan_name: 'EAT_20', gillan_item_no: 81},
    {question: 
      {prompt: 'I give too much time and thought to food.', labels: eat_choices, name: 'eat_fifteen', required: true}, survey_question_no: 21, gillan_name: 'EAT_21', gillan_item_no: 82},
    {question: 
      {prompt: 'I feel uncomfortable after eating sweets.', labels: eat_choices, name: 'eat_sixteen', required: true}, survey_question_no: 22, gillan_name: 'EAT_22', gillan_item_no: 83},
    {question: 
      {prompt: 'I engage in dieting behaviour.', labels: eat_choices, name: 'eat_seventeen', required: true}, survey_question_no: 23, gillan_name: 'EAT_23', gillan_item_no: 84},
    {question: 
      {prompt: 'I like my stomach to be empty.', labels: eat_choices, name: 'eat_eighteen', required: true}, survey_question_no: 24, gillan_name: 'EAT_24', gillan_item_no: 85}
  ]
};

let bis_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following statements describes ways in which you may or may not act and think.</p>'+
              '<p>Read each statement and choose the option that best describes <strong>how often</strong> you act or think in that way.</p>'+
            '</div>',
  choices: ['Continue']
  };

let bis_choices = [
  'Rarely/Never',
  'Occasionally',
  'Often',
  'Almost always / always'
  ];

let bis_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      data: {
        reversed_scoring: jsPsych.timelineVariable('reversed'),
        questionnaire: 'BIS',
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '600',
      font_size: [
        {statement: '1.5em', response: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_BIS_qs = jsPsych.data.get().filter({questionnaire: 'BIS'}).count();
        let reversed = jsPsych.data.get().last(1).values()[0].reversed_scoring;
        score = parseInt(score_str)+1;
        if (reversed){
          data.score = 5-score;
        } else {
          data.score = score;
        }
        if (no_BIS_qs==5) { // 3 in 70-question version
          data.BIS_total = jsPsych.data.get().filter({questionnaire: 'BIS'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I have "racing" thoughts.', labels: bis_choices, name: 'bis_one', required: true}, reversed: false, survey_question_no: 6, gillan_name: 'BIS_6', gillan_item_no: 161},
    {question: 
      {prompt: 'I concentrate easily.', labels: bis_choices, name: 'bis_two', required: true}, reversed: true, survey_question_no: 9, gillan_name: 'BIS_9', gillan_item_no: 164},
    {question: 
      {prompt: 'I save regularly.', labels: bis_choices, name: 'bis_three', required: true},  reversed: true, survey_question_no: 10, gillan_name: 'BIS_10', gillan_item_no: 165}, // not in 70
    {question:
      {prompt: 'I plan for job security.', labels: bis_choices, name: 'bis_four', required: true}, reversed: true, survey_question_no: 13, gillan_name: 'BIS_13', gillan_item_no: 168},
    {question: 
      {prompt: 'I say things without thinking.', labels: bis_choices, name: 'bis_five', required: true}, reversed: false, survey_question_no: 14, gillan_name: 'BIS_14', gillan_item_no: 169} // not in 70
  ]
};

let stai_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following statements are used by people to describe themselves.</p>'+
              '<p>Read each statement and choose the option that best describes how you <strong>generally feel</strong>.</p>'+
            '</div>',
  choices: ['Continue']
};

let stai_choices = [
  'Almost never',
  'Sometimes',
  'Often',
  'Almost always'
];

let stai_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>Generally...</em>',
      data: {
        reversed_scoring: jsPsych.timelineVariable('reversed'),
        questionnaire: jsPsych.timelineVariable('questionnaire'), 
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '600',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_STAI_qs = jsPsych.data.get().filter({questionnaire: 'STAI'}).count();
        let reversed = jsPsych.data.get().last(1).values()[0].reversed_scoring;
        let catch_question = jsPsych.data.get().last(1).values()[0].questionnaire == 'catch_questions';
        if (catch_question) {
          let score = parseInt(score_str);
          data.catch_question_pass = score == 0;
        } else {
          score = parseInt(score_str)+1;
          if (reversed){
            data.score = 5-score;
          } else {
            data.score = score;
          }
          if (no_STAI_qs==13) { // 12 in 70-question version
            data.STAI_total = jsPsych.data.get().filter({questionnaire: 'STAI'}).select('score').sum();
          }
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I feel pleasant.', labels: stai_choices, name: 'stai_one', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 1, gillan_name: 'STAI_1', gillan_item_no: 136},
    {question: 
      {prompt: 'I feel satisfied with myself.', labels: stai_choices, name: 'stai_two', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 3, gillan_name: 'STAI_3', gillan_item_no: 138},
    {question: 
      {prompt: 'I wish I could be as happy as others seem to be.', labels: stai_choices, name: 'stai_three', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 4, gillan_name: 'STAI_4', gillan_item_no: 139},  
    {question: 
      {prompt: 'I feel like a failure.', labels: stai_choices, name: 'stai_four', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 5, gillan_name: 'STAI_5', gillan_item_no: 140},
    {question: 
      {prompt: 'I feel that difficulties are piling up so that I cannot overcome them.', labels: stai_choices, name: 'stai_five', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 8, gillan_name: 'STAI_8', gillan_item_no: 143},
    {question: 
      {prompt: 'I am happy.', labels: stai_choices, name: 'stai_six', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 10, gillan_name: 'STAI_10', gillan_item_no: 145},
    {question: 
      {prompt: 'I lack self-confidence.', labels: stai_choices, name: 'stai_seven', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 12, gillan_name: 'STAI_12', gillan_item_no: 147},
    {question: 
      {prompt: 'I feel secure.', labels: stai_choices, name: 'stai_eight', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 13, gillan_name: 'STAI_13', gillan_item_no: 148},
    {question: 
      {prompt: 'Please answer "Almost never" to this question.', labels: stai_choices, name: 'catch_question', required: true}, questionnaire: 'catch_questions', reversed: false, survey_question_no: 2},
    {question: 
      {prompt: 'I feel inadequate.', labels: stai_choices, name: 'stai_nine', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 15, gillan_name: 'STAI_15', gillan_item_no: 150},
    {question: 
      {prompt: 'I am content.', labels: stai_choices, name: 'stai_ten', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 16, gillan_name: 'STAI_16', gillan_item_no: 151},
    {question: 
      {prompt: 'Some unimportant thought runs through my mind and bothers me.', labels: stai_choices, name: 'stai_eleven', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 17, gillan_name: 'STAI_17', gillan_item_no: 152},  
    {question: 
      {prompt: 'I am a steady person.', labels: stai_choices, name: 'stai_twelve', required: true}, questionnaire: 'STAI', reversed: true, survey_question_no: 19, gillan_name: 'STAI_19', gillan_item_no: 154},
    {question: 
      {prompt: 'I get in a state of tension or turmoil as I think over my recent concerns and interests.', labels: stai_choices, name: 'stai_thirteen', required: true}, questionnaire: 'STAI', reversed: false, survey_question_no: 20, gillan_name: 'STAI_20', gillan_item_no: 155} // not in 70
  ]
};

let aes_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>For each of the following statements, select the option that best describes your thoughts, feelings, and actions during the <strong>past 4 weeks</strong>.</p>'+
            '</div>',
  choices: ['Continue']
  };

let aes_choices = [
  'Not at all characteristic',
  'Slightly characteristic (minimal)',
  'Somewhat characteristic (moderate)',
  'Very characteristic </br>(a great deal)'
];

let aes_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>Over the past 4 weeks, I have felt that...</em>',
      data: {
        questionnaire: 'AES',
        question_no: jsPsych.timelineVariable('survey_question_no'),
        gillan_name: jsPsych.timelineVariable('gillan_name'),
        gillan_item_no: jsPsych.timelineVariable('gillan_item_no')
      },
      scale_width: '900',
      font_size: [
        {statement: '1.5em', response: '1em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_AES_qs = jsPsych.data.get().filter({questionnaire: 'AES'}).count();
        data.score = 3-parseInt(score_str);
        if (no_AES_qs==2) {
          data.AES_total = jsPsych.data.get().filter({questionnaire: 'AES'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I have initiative.', labels: aes_choices, name: 'aes_one', required: true}, survey_question_no: 17, gillan_name: 'AES_17', gillan_item_no: 104},
    {question: 
      {prompt: 'I have motivation.', labels: aes_choices, name: 'aes_two', required: true}, survey_question_no: 18, gillan_name: 'AES_18', gillan_item_no: 105}
  ]
};

// AUDIT NOT IN 70-question version //

let audit_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following question is about how frequently you consume alcohol.</p>'+
            '</div>',
  choices: ['Continue']
  };

let audit_question = {
  type: 'survey-likert',
  questions: [
    {
    prompt: 'How often do you have six or more drinks on one occasion?', 
    labels: ['Never', 'Less than monthly', 'Monthly', 'Weekly', 'Daily or almost daily'], 
    name:'audit_one',
    required: true
  }
],
  data: {
    questionnaire: 'AUDIT',
    question_no: 3,
    gillan_name: 'AUDIT_3',
    gillan_item_no: 108
  },
  scale_width: '900',
  font_size: [
    {statement: '1.5em', response: '1em'}
  ],
  button_label: 'Next',
  on_finish: function(data) {
    let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
    data.score = parseInt(score_str);
    data.AUDIT_score = parseInt(score_str);
  }
};

let anhedonia_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>In the following section, you will receive a prompt to input some things you enjoy doing or taking part in.</p>'+
              '<p>You will then be asked to rate some of your feelings towards these things.</p>'+
            '</div>',
  choices: ['Continue']
};

let anhedonia_choices = [
  'Not at all',
  'Slightly',
  'Moderately',
  'Mostly',
  'Very much'
];

let anhedonia_partA = {
  type: 'survey-text',
  preamble: 
    '<p style="font-size:1.25em">'+
      '<span class="tooltip">Please list 2 of your favourite pastimes/hobbies that are <strong>not</strong> primarily social (hover for examples):'+
        '<span style="font-size:0.8em;line-height:1.2" class="tooltiptext">e.g. cooking, gardening, video games, working out, reading, making/playing music...</span>'+
      '</span>'+
    '</p>',
  questions: [
    {prompt: "1.", rows: 1, columns: 20, new_line: false, required: true, name: "1."}, 
    {prompt: "2.", rows: 1, columns: 20, new_line: false, required: true, name: "2."}
  ],
  button_label: 'Next',
  data: {anhedonia_part: 'A'},
  on_finish: function(data) {
    let hobbies_list = jsPsych.data.get().last(1).values()[0].responses.replace('1.','').replace('2.','').match(/[a-z,{}&0-9"\- ]/gi).join('').replace(/""/gi,'');
    data.hobbies_list = hobbies_list;
    data.hobby_1 = hobbies_list.substr(2,hobbies_list.indexOf('\",\"')-2);
    data.hobby_2 = hobbies_list.substr(hobbies_list.indexOf('\",\"')+3).replace('\"}','');
  }
};

let anhedonia_partA_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: function() {
        let str = 'My favourite activities: ';
        let hobby1 = jsPsych.data.get().filter({anhedonia_part: 'A'}).select('hobby_1').values[0];
        let hobby2 = jsPsych.data.get().filter({anhedonia_part: 'A'}).select('hobby_2').values[0];
        hobbies = str.concat('<em>',hobby1,'</em>',' & ','<em>',hobby2,'</em>');
        return hobbies
      },
      data: {questionnaire: 'DARS', subscale: 'hobbies', question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        data.score = parseInt(score_str);
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I would enjoy these activities.', labels: anhedonia_choices, name: 'anhedA_one', required: true}, survey_question_no: 1},
    {question: 
      {prompt: 'I would spend time doing these activities.', labels: anhedonia_choices, name: 'anhedA_two', required: true}, survey_question_no: 2},
    {question: 
      {prompt: 'I want to do these activities.', labels: anhedonia_choices, name: 'anhedA_three', required: true}, survey_question_no: 3},
    {question: 
      {prompt: 'These activities would interest me.', labels: anhedonia_choices, name: 'anhedA_four', required: true}, survey_question_no: 4}
  ]
};

let anhedonia_partB = {
  type: 'survey-text',
  preamble: 
    '<p style="font-size:1.25em">'+
      'Please list 2 of your favourite <strong>foods</strong> or <strong>drinks</strong>:'+
    '</p>',
  questions: [
    {prompt: "1.", rows: 1, columns: 20, new_line: false, required: true, name: "1."}, 
    {prompt: "2.", rows: 1, columns: 20, new_line: false, required: true, name: "2."}
  ],
  button_label: 'Next',
  data: {anhedonia_part: 'B'},
  on_finish: function(data) {
    let food_drink_list = jsPsych.data.get().last(1).values()[0].responses.replace('1.','').replace('2.','').match(/[a-z,{}&0-9"\- ]/gi).join('').replace(/""/gi,'');
    data.food_drink_list = food_drink_list;
    data.food_1 = food_drink_list.substr(2,food_drink_list.indexOf('\",\"')-2);
    data.food_2 = food_drink_list.substr(food_drink_list.indexOf('\",\"')+3).replace('\"}','');
  }
};

let anhedonia_partB_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: function() {
        let str = 'My favourite foods/drinks: ';
        let food1 = jsPsych.data.get().filter({anhedonia_part: 'B'}).select('food_1').values[0];
        let food2 = jsPsych.data.get().filter({anhedonia_part: 'B'}).select('food_2').values[0];
        food_drink = str.concat('<em>',food1,'</em>',' & ','<em>',food2,'</em>');
        return food_drink
      },
      data: {questionnaire: 'DARS', subscale: 'food_drink', question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        data.score = parseInt(score_str);
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I would make an effort to get/make these foods/drinks.', labels: anhedonia_choices, name: 'anhedB_one', required: true}, survey_question_no: 5},
    {question: 
      {prompt: 'I would enjoy these foods/drinks.', labels: anhedonia_choices, name: 'anhedB_two', required: true}, survey_question_no: 6},
    {question: 
      {prompt: 'I want to have these foods/drinks.', labels: anhedonia_choices, name: 'anhedB_three', required: true}, survey_question_no: 7},
    {question: 
      {prompt: 'I would eat as much of these foods as I could.', labels: anhedonia_choices, name: 'anhedB_four', required: true}, survey_question_no: 8}
  ]
};

let anhedonia_partC = {
  type: 'survey-text',
  preamble: 
    '<p style="font-size:1.25em">'+
      '<span class="tooltip">Please list 2 of your favourite <strong>social activities</strong> (hover for examples):'+
        '<span style="font-size:0.8em;line-height:1.2" class="tooltiptext">e.g. concerts, house parties, social media, going out for food/drinks, playing football...</span>'+
      '</span>'+
    '</p>',
  questions: [
    {prompt: "1.", rows: 1, columns: 20, new_line: false, required: true, name: "1."}, 
    {prompt: "2.", rows: 1, columns: 20, new_line: false, required: false, name: "2."}
  ],
  button_label: 'Next',
  data: {anhedonia_part: 'C'},
  on_finish: function(data) {
    let social_activities_list = jsPsych.data.get().last(1).values()[0].responses.replace('1.','').replace('2.','').match(/[a-z,{}&0-9"\- ]/gi).join('').replace(/""/gi,'');
    data.social_activities_list = social_activities_list;
    data.social_activity_1 = social_activities_list.substr(2,social_activities_list.indexOf('\",\"')-2);
    data.social_activity_2 = social_activities_list.substr(social_activities_list.indexOf('\",\"')+3).replace('\"}','');
  }
};

let anhedonia_partC_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: function() {
        let str = 'My favourite social activities: ';
        let social_activity1 = jsPsych.data.get().filter({anhedonia_part: 'C'}).select('social_activity_1').values[0];
        let social_activity2 = jsPsych.data.get().filter({anhedonia_part: 'C'}).select('social_activity_2').values[0];
        social_activities = str.concat('<em>',social_activity1,'</em>',' & ','<em>',social_activity2,'</em>');
        return social_activities
      },
      data: {questionnaire: 'DARS', subscale: 'social', question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        data.score = parseInt(score_str);
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'Spending time doing these things would make me happy.', labels: anhedonia_choices, name: 'anhedC_one', required: true}, survey_question_no: 9},
    {question: 
      {prompt: 'I would be interested in doing things that involve other people.', labels: anhedonia_choices, name: 'anhedC_two', required: true}, survey_question_no: 10},
    {question: 
      {prompt: 'I would be the one to plan these activities.', labels: anhedonia_choices, name: 'anhedC_three', required: true}, survey_question_no: 11},
    {question: 
      {prompt: 'I would actively participate in these social activities.', labels: anhedonia_choices, name: 'anhedC_four', required: true}, survey_question_no: 12}
  ]
};

let anhedonia_partD = {
  type: 'survey-text',
  preamble: 
    '<p style="font-size:1.25em">'+
      '<span class="tooltip">Please list 2 of your favourite <strong>sensory experiences</strong> (hover for examples):'+
        '<span style="font-size:0.8em;line-height:1.2" class="tooltiptext">e.g. smells (nature, bread), touch (hugs, petting a dog), hearing (listening to music/podcasts), '+
          'sight (sunrises, fireworks), other (being by water, meditation)...</span>'+
      '</span>'+
    '</p>',
  questions: [
    {prompt: "1.", rows: 1, columns: 20, new_line: false, required: true, name: "1."}, 
    {prompt: "2.", rows: 1, columns: 20, new_line: false, required: true, name: "2."}
  ],
  button_label: 'Next',
  data: {anhedonia_part: 'D'},
  on_finish: function(data) {
    let sensory_exp_list = jsPsych.data.get().last(1).values()[0].responses.replace('1.','').replace('2.','').match(/[a-z,{}&0-9"\- ]/gi).join('').replace(/""/gi,'');
    data.sensory_exp_list = sensory_exp_list;
    data.sensory_experience_1 = sensory_exp_list.substr(2,sensory_exp_list.indexOf('\",\"')-2);
    data.sensory_experience_2 = sensory_exp_list.substr(sensory_exp_list.indexOf('\",\"')+3).replace('\"}','');
  }
};

let anhedonia_partD_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: function() {
        let str = 'My favourite sensory experiences: ';
        let sensory_experience1 = jsPsych.data.get().filter({anhedonia_part: 'D'}).select('sensory_experience_1').values[0];
        let sensory_experience2 = jsPsych.data.get().filter({anhedonia_part: 'D'}).select('sensory_experience_2').values[0];
        sensory_experiences = str.concat('<em>',sensory_experience1,'</em>',' & ','<em>',sensory_experience2,'</em>');
        return sensory_experiences
      },
      data: {questionnaire: 'DARS', subscale: 'sensory', question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let question_no = jsPsych.data.get().last(1).values()[0].question_no;
        data.score = parseInt(score_str);
        if (question_no==17) {
          data.DARS_hobbies = jsPsych.data.get().filter({questionnaire: 'DARS', subscale: 'hobbies'}).select('score').sum();
          data.DARS_food_drink = jsPsych.data.get().filter({questionnaire: 'DARS', subscale: 'food_drink'}).select('score').sum();
          data.DARS_social = jsPsych.data.get().filter({questionnaire: 'DARS', subscale: 'social'}).select('score').sum();
          data.DARS_sensory = jsPsych.data.get().filter({questionnaire: 'DARS', subscale: 'sensory'}).select('score').sum();

          data.DARS_total = jsPsych.data.get().filter({questionnaire: 'DARS'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I would actively seek out these experiences.', labels: anhedonia_choices, name: 'anhedD_one', required: true}, survey_question_no: 13},
    {question: 
      {prompt: 'I get excited thinking about these experiences.', labels: anhedonia_choices, name: 'anhedD_two', required: true}, survey_question_no: 14},
    {question: 
      {prompt: 'If I were to have these experiences I would savour every moment.', labels: anhedonia_choices, name: 'anhedD_three', required: true}, survey_question_no: 15},
    {question: 
      {prompt: 'I want to have these experiences.', labels: anhedonia_choices, name: 'anhedD_four', required: true}, survey_question_no: 16},
    {question: 
      {prompt: 'I would make an effort to spend time having these experiences.', labels: anhedonia_choices, name: 'anhedD_five', required: true}, survey_question_no: 17}
  ]
};

let mfis_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following statements describe different possible effects of <strong>fatigue</strong> or tiredness.</p>'+
              '<p>Read each statement and choose the option that best describes how often <strong>fatigue</strong> has affected you this way over the <strong>past 4 weeks</strong>.</p>'+
            '</div>',
  choices: ['Continue']
};

let mfis_choices = [
  'Never',
  'Rarely',
  'Sometimes',
  'Often',
  'Almost always'
];

let mfis_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>Because of my fatigue during the past 4 weeks...</em>',
      data: {questionnaire: jsPsych.timelineVariable('questionnaire'), subscale: jsPsych.timelineVariable('subscale'), question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '650',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let catch_question = jsPsych.data.get().last(1).values()[0].questionnaire == 'catch_questions';
        if (catch_question) {
          let score = parseInt(score_str);
          data.catch_question_pass = score == 0;
        } else {
          let no_MFIS_qs = jsPsych.data.get().filter({questionnaire: 'MFIS'}).count();
          data.score = parseInt(score_str);
          if (no_MFIS_qs==21) {
            data.MFIS_physical = jsPsych.data.get().filter({questionnaire: 'MFIS', subscale: 'physical'}).select('score').sum();
            data.MFIS_cognitive = jsPsych.data.get().filter({questionnaire: 'MFIS', subscale: 'cognitive'}).select('score').sum();
            data.MFIS_psychosocial = jsPsych.data.get().filter({questionnaire: 'MFIS', subscale: 'psychosocial'}).select('score').sum();
            data.MFIS_total = jsPsych.data.get().filter({questionnaire: 'MFIS'}).select('score').sum();
          }
        }          
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I have been less alert.', labels: mfis_choices, name: 'mfis_one', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 1},
    {question: 
      {prompt: 'I have had difficulty paying attention for long periods of time.', labels: mfis_choices, name: 'mfis_two', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 2},
    {question: 
      {prompt: 'I have been unable to think clearly.', labels: mfis_choices, name: 'mfis_three', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 3},
    {question: 
      {prompt: 'I have been clumsy and uncoordinated.', labels: mfis_choices, name: 'mfis_four', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 4},
    {question: 
      {prompt: 'I have been forgetful.', labels: mfis_choices, name: 'mfis_five', required: true},  questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 5},
    {question: 
      {prompt: 'I have had to pace myself in my physical activities.', labels: mfis_choices, name: 'mfis_six', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 6},
    {question: 
      {prompt: 'I have been less motivated to do anything that requires physical effort.', labels: mfis_choices, name: 'mfis_seven', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 7},
    {question: 
      {prompt: 'I have been less motivated to participate in social activities.', labels: mfis_choices, name: 'mfis_eight', required: true}, questionnaire: 'MFIS', subscale: 'psychosocial', survey_question_no: 8},
    {question: 
      {prompt: 'I have been limited in my ability to do things away from home.', labels: mfis_choices, name: 'mfis_nine', required: true}, questionnaire: 'MFIS', subscale: 'psychosocial', survey_question_no: 9},
    {question: 
      {prompt: 'I have trouble maintaining physical effort for long periods.', labels: mfis_choices, name: 'mfis_ten', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 10},
    {question: 
      {prompt: 'I have had difficulty making decisions.', labels: mfis_choices, name: 'mfis_eleven', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 11},
    {question: 
      {prompt: 'I have been less motivated to do anything that requires thinking.', labels: mfis_choices, name: 'mfis_twelve', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 12},
    {question: 
      {prompt: 'My muscles have felt weak.', labels: mfis_choices, name: 'mfis_thirteen', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 13},
    {question: 
      {prompt: 'I have been physically uncomfortable.', labels: mfis_choices, name: 'mfis_fourteen', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 14},
    {question: 
      {prompt: 'I have had trouble finishing tasks that require thinking.', labels: mfis_choices, name: 'mfis_fifteen', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 15},
    {question: 
      {prompt: 'I have stopped breathing entirely for a couple of days or more (without the aid of medical equipment).', labels: mfis_choices, name: 'catch_question', required: true}, questionnaire: 'catch_questions', subscale: 'catch_questions', survey_question_no: 4},
    {question: 
      {prompt: 'I have had difficulty organising my thoughts when doing things at home or at work.', labels: mfis_choices, name: 'mfis_sixteen', required: true},  questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 16},
    {question: 
      {prompt: 'I have been less able to complete tasks that require physical effort.', labels: mfis_choices, name: 'mfis_seventeen', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 17},
    {question: 
      {prompt: 'My thinking has been slowed down.', labels: mfis_choices, name: 'mfis_eighteen', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 18},
    {question: 
      {prompt: 'I have had trouble concentrating.', labels: mfis_choices, name: 'mfis_nineteen', required: true}, questionnaire: 'MFIS', subscale: 'cognitive', survey_question_no: 19},
    {question: 
      {prompt: 'I have limited my physical activities.', labels: mfis_choices, name: 'mfis_twenty', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 20},
    {question: 
      {prompt: 'I have needed to rest more often or for longer periods.', labels: mfis_choices, name: 'mfis_twentyone', required: true}, questionnaire: 'MFIS', subscale: 'physical', survey_question_no: 21}
  ]
};

let bpq_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>The following statements relate to various bodily characteristics.</p>'+
              '<p>Read each statement and choose the option that best describes how often you are <strong>aware</strong> of this characteristic.</p>'+
            '</div>',
  choices: ['Continue']
};

let bpq_choices = [
  'Never',
  'Occasionally',
  'Sometimes',
  'Usually',
  'Always'
];

let bpq_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      preamble: '<em>During most situations I am aware of...</em>',
      data: {questionnaire: 'BPQ', question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '750',
      font_size: [
        {statement: '1.5em', response: '1.15em', preamble: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let no_BPQ_qs = jsPsych.data.get().filter({questionnaire: 'BPQ'}).count();
        data.score = parseInt(score_str)+1;
        if (no_BPQ_qs==12) {           
          data.BPQ_total = jsPsych.data.get().filter({questionnaire: 'BPQ'}).select('score').sum();
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'My mouth being dry.', labels: bpq_choices, name: 'bpq_one', required: true}, survey_question_no: 1},
    {question: 
      {prompt: 'How fast I am breathing.', labels: bpq_choices, name: 'bpq_two', required: true}, survey_question_no: 2},
    {question: 
      {prompt: 'A swelling of my body or parts of my body.', labels: bpq_choices, name: 'bpq_three', required: true}, survey_question_no: 3},
    {question: 
      {prompt: 'Muscle tension in my arms and legs.', labels: bpq_choices, name: 'bpq_four', required: true}, survey_question_no: 4},
    {question: 
      {prompt: 'A bloated feeling because of water retention.', labels: bpq_choices, name: 'bpq_five', required: true},  survey_question_no: 5},
    {question: 
      {prompt: 'Goose bumps.', labels: bpq_choices, name: 'bpq_six', required: true}, survey_question_no: 6},
    {question: 
      {prompt: 'Stomach and gut pains.', labels: bpq_choices, name: 'bpq_seven', required: true}, survey_question_no: 7},
    {question: 
      {prompt: 'Stomach distension or bloatedness.', labels: bpq_choices, name: 'bpq_eight', required: true}, survey_question_no: 8},
    {question: 
      {prompt: 'Tremor in my lips.', labels: bpq_choices, name: 'bpq_nine', required: true}, survey_question_no: 9},
    {question: 
      {prompt: 'The hair on the back of my neck "standing up".', labels: bpq_choices, name: 'bpq_ten', required: true}, survey_question_no: 10},
    {question: 
      {prompt: 'An urge to swallow.', labels: bpq_choices, name: 'bpq_eleven', required: true}, survey_question_no: 11},
    {question: 
      {prompt: 'How hard my heart is beating.', labels: bpq_choices, name: 'bpq_twelve', required: true}, survey_question_no: 12}
  ]
};

let spqbru_instructions = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;line-height:1.5;max-width:1440px;">'+
              '<p>Read each of the following statements, and pick the option which best describes the extent to which you <strong>agree</strong>.</p>'+
            '</div>',
  choices: ['Continue']
};

let spqbru_choices = [
  'Strongly disagree',
  'Disagree',
  'Neutral',
  'Agree',
  'Strongly agree'
];

let spqbru_questions = {
  timeline: [
    {
      type: 'survey-likert',
      questions: [jsPsych.timelineVariable('question')],
      data: {questionnaire: jsPsych.timelineVariable('questionnaire'), higher_order: jsPsych.timelineVariable('higher_order'), subfactor: jsPsych.timelineVariable('subfactor'), question_no: jsPsych.timelineVariable('survey_question_no')},
      scale_width: '750',
      font_size: [
        {statement: '1.5em', response: '1.15em'}
      ],
      button_label: 'Next',
      on_finish: function(data) {
        let score_str = jsPsych.data.get().last(1).values()[0].responses.match(/[0-4]/g);
        let catch_question = jsPsych.data.get().last(1).values()[0].questionnaire == 'catch_questions';
        if (catch_question) {
          let score = parseInt(score_str);
          data.catch_question_pass = score == 4
        } else {
          let no_SPQ_qs = jsPsych.data.get().filter({questionnaire: 'SPQ'}).count();
          data.score = parseInt(score_str);
          if (no_SPQ_qs==32) {
            data.SPQ_cognitive_perceptual = jsPsych.data.get().filter({questionnaire: 'SPQ', higher_order: 'cognitive_perceptual'}).select('score').sum();
            data.SPQ_interpersonal = jsPsych.data.get().filter({questionnaire: 'SPQ', higher_order: 'interpersonal'}).select('score').sum();
            data.SPQ_disorganised = jsPsych.data.get().filter({questionnaire: 'SPQ', higher_order: 'disorganised'}).select('score').sum();

            data.SPQ_ideas_of_reference = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'ideas_of_reference'}).select('score').sum();
            data.SPQ_suspiciousness = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'suspiciousness'}).select('score').sum();
            data.SPQ_no_close_friends = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'no_close_friends'}).select('score').sum();
            data.SPQ_constricted_affect = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'constricted_affect'}).select('score').sum();
            data.SPQ_eccentric_behaviour = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'eccentric_behaviour'}).select('score').sum();
            data.SPQ_social_anxiety = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'social_anxiety'}).select('score').sum();
            data.SPQ_magical_thinking = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'magical_thinking'}).select('score').sum();
            data.SPQ_odd_speech = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'odd_speech'}).select('score').sum();
            data.SPQ_unusual_perceptions = jsPsych.data.get().filter({questionnaire: 'SPQ', subfactor: 'unusual_perceptions'}).select('score').sum();

            data.SPQ_total = jsPsych.data.get().filter({questionnaire: 'SPQ'}).select('score').sum();
          }
        }
      }
    }
  ],
  timeline_variables: [
    {question: 
      {prompt: 'I sometimes feel that people are talking about me.', labels: spqbru_choices, name: 'spqbru_one', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'ideas_of_reference', survey_question_no: 1},
    {question: 
      {prompt: 'I sometimes feel that other people are watching me.', labels: spqbru_choices, name: 'spqbru_two', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'ideas_of_reference', survey_question_no: 2},
    {question: 
      {prompt: 'When shopping, I get the feeling that other people are taking notice of me.', labels: spqbru_choices, name: 'spqbru_three', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'ideas_of_reference', survey_question_no: 3},
    {question: 
      {prompt: 'I often feel that others have it in for me.', labels: spqbru_choices, name: 'spqbru_four', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'suspiciousness', survey_question_no: 4},
    {question: 
      {prompt: 'I sometimes get concerned that friends or co-workers are not really loyal or trustworthy.', labels: spqbru_choices, name: 'spqbru_five', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'suspiciousness', survey_question_no: 5},
    {question: 
      {prompt: 'I often have to keep an eye out to stop people from taking advantage of me.', labels: spqbru_choices, name: 'spqbru_six', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'suspiciousness', survey_question_no: 6},
    {question: 
      {prompt: 'I feel that I cannot get "close" to people.', labels: spqbru_choices, name: 'spqbru_seven', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'no_close_friends', survey_question_no: 7},
    {question: 
      {prompt: 'I find it hard to be emotionally close to other people.', labels: spqbru_choices, name: 'spqbru_eight', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'no_close_friends', survey_question_no: 8},
    {question: 
      {prompt: 'I feel that there is no one I am really close to outside of my immediate family, or people I can confide in or talk to about personal problems.', labels: spqbru_choices, name: 'spqbru_nine', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'no_close_friends', survey_question_no: 9},
    {question: 
      {prompt: 'I tend to keep my feelings to myself.', labels: spqbru_choices, name: 'spqbru_ten', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'constricted_affect', survey_question_no: 10},
    {question: 
      {prompt: 'I rarely laugh and smile.', labels: spqbru_choices, name: 'spqbru_eleven', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'constricted_affect', survey_question_no: 11},
    {question: 
      {prompt: 'I am not good at expressing my true feelings by the way I talk and look.', labels: spqbru_choices, name: 'spqbru_twelve', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'constricted_affect', survey_question_no: 12},
    {question: 
      {prompt: 'Other people see me as slightly eccentric (odd).', labels: spqbru_choices, name: 'spqbru_thirteen', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'eccentric_behaviour', survey_question_no: 13},
    {question: 
      {prompt: 'I am an odd, unusual person.', labels: spqbru_choices, name: 'spqbru_fourteen', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'eccentric_behaviour', survey_question_no: 14},
    {question: 
      {prompt: 'I have some eccentric (odd) habits.', labels: spqbru_choices, name: 'spqbru_fifteen', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'eccentric_behaviour', survey_question_no: 15},
    {question: 
      {prompt: 'People sometimes comment on my unusual mannerisms and habits.', labels: spqbru_choices, name: 'spqbru_sixteen', required: true},  questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'eccentric_behaviour', survey_question_no: 16},
    {question: 
      {prompt: 'I often feel nervous when I am in a group of unfamiliar people.', labels: spqbru_choices, name: 'spqbru_seventeen', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'social_anxiety', survey_question_no: 17},
    {question: 
      {prompt: 'I get anxious when meeting people for the first time.', labels: spqbru_choices, name: 'spqbru_eighteen', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'social_anxiety', survey_question_no: 18},
    {question: 
      {prompt: 'I feel very uncomfortable in social situations involving unfamiliar people.', labels: spqbru_choices, name: 'spqbru_nineteen', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'social_anxiety', survey_question_no: 19},
    {question: 
      {prompt: 'I sometimes avoid going to places where there will be many people because I will get anxious.', labels: spqbru_choices, name: 'spqbru_twenty', required: true}, questionnaire: 'SPQ', higher_order: 'interpersonal', subfactor: 'social_anxiety', survey_question_no: 20},
    {question: 
      {prompt: 'I believe in telepathy (mind-reading).', labels: spqbru_choices, name: 'spqbru_twentyone', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'magical_thinking', survey_question_no: 21},
    {question: 
      {prompt: 'Please answer "Strongly agree" to this question.', labels: spqbru_choices, name: 'catch_question', required: true}, questionnaire: 'catch_questions', higher_order: 'catch_questions', subfactor: 'catch_questions', survey_question_no: 1},
    {question: 
      {prompt: 'I believe in clairvoyance (psychic forces, fortune telling).', labels: spqbru_choices, name: 'spqbru_twentytwo', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'magical_thinking', survey_question_no: 22},
    {question: 
      {prompt: 'I have had experiences with astrology, seeing the future, UFOs, ESP, or a sixth sense.', labels: spqbru_choices, name: 'spqbru_twentythree', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'magical_thinking', survey_question_no: 23},
    {question: 
      {prompt: 'I have felt that I was communicating with another person telepathically (by mind-reading).', labels: spqbru_choices, name: 'spqbru_twentyfour', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'magical_thinking', survey_question_no: 24},
    {question: 
      {prompt: 'I sometimes jump quickly from one topic to another when speaking.', labels: spqbru_choices, name: 'spqbru_twentyfive', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'odd_speech', survey_question_no: 25},
    {question: 
      {prompt: 'I tend to wander off the topic when having a conversation.', labels: spqbru_choices, name: 'spqbru_twentysix', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'odd_speech', survey_question_no: 26},
    {question: 
      {prompt: 'I often ramble on too much when speaking.', labels: spqbru_choices, name: 'spqbru_twentyseven', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'odd_speech', survey_question_no: 27},
    {question: 
      {prompt: 'I sometimes forget what I am trying to say.', labels: spqbru_choices, name: 'spqbru_twentyeight', required: true}, questionnaire: 'SPQ', higher_order: 'disorganised', subfactor: 'odd_speech', survey_question_no: 28},
    {question: 
      {prompt: 'I often hear a voice speaking my thought aloud.', labels: spqbru_choices, name: 'spqbru_twentynine', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'unusual_perceptions', survey_question_no: 29},
    {question: 
      {prompt: 'When I look at a person or at myself in a mirror, I have seen the face change right before my eyes.', labels: spqbru_choices, name: 'spqbru_thirty', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'unusual_perceptions', survey_question_no: 30},
    {question: 
      {prompt: 'My thoughts are sometimes so strong that I can almost hear them.', labels: spqbru_choices, name: 'spqbru_thirtyone', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'unusual_perceptions', survey_question_no: 31},
    {question: 
      {prompt: 'Everyday things seem unusually large or small.', labels: spqbru_choices, name: 'spqbru_thirtytwo', required: true}, questionnaire: 'SPQ', higher_order: 'cognitive_perceptual', subfactor: 'unusual_perceptions', survey_question_no: 32}
  ]
};

let zds = {
  timeline: [zung_instructions, zung_questions]
};

let ocir = {
  timeline: [ocir_instructions, ocir_questions]
};

let lsas = {
  timeline: [lsas_fear_instructions, lsas_fear_questions, lsas_avoid_instructions, lsas_avoid_questions]
};

let eat = {
  timeline: [eat_instructions, eat_questions]
};

let bis = {
  timeline: [bis_instructions, bis_questions]
}

let stai = {
  timeline: [stai_instructions, stai_questions]
}

let aes = {
  timeline: [aes_instructions, aes_questions]
}

let audit = {
  timeline: [audit_instructions, audit_question]
}

let dars = {
  timeline: [
    anhedonia_instructions, anhedonia_partA, anhedonia_partA_questions, anhedonia_partB, anhedonia_partB_questions, 
    anhedonia_partC, anhedonia_partC_questions, anhedonia_partD, anhedonia_partD_questions
  ]
}

let mfis = {
  timeline: [mfis_instructions, mfis_questions]
}

let bpq = {
  timeline: [bpq_instructions, bpq_questions]
}

let spqbru = {
  timeline: [spqbru_instructions, spqbru_questions]
}

let questionnaire_order = jsPsych.randomization.shuffle([zds, ocir, lsas, eat, bis, stai, aes, audit, dars, mfis, bpq, spqbru]);

let all_questions = {
  timeline: questionnaire_order
}

timeline.push(instructions, disclaimer, all_questions);

let finish = {
    type: 'html-button-response',
    stimulus: '<div style="font-size:1.5em;color:#6B6D8C;line-height:1">'+
                '<p><h2>Thank you! You have completed the questionnaires.</p></h2>'+
              '</div>'+
              '<div style="font-size:1.5em;color:#6B6D8C;max-width:1440px">'+
                '<p>You are almost done! You will be shown a short debrief document on the next screen, and then finally a short survey to tell us how you have found the experiment.</p>'+
                '<p>Press <em>Continue</em> to proceed.</p>'+
              '</div>',
    choices: ['Continue']
};

let debrief = {
  type: 'survey-html-form',
  html: '<p style="font-size:1.25em"><em>Please read through the document, tick the box underneath the document (at the bottom of the webpage) to confirm you have read it'+
          ', and then press Next to continue.</em></p>'+
        '<div class="embed-responsive">'+
        '<object data="files/debrief.pdf" type="application/pdf" style="width:80vw;height:70vh"></object>'+
        '</div>'+
        '<p style="font-size:1.25em"><input type="checkbox" id="consent" name="consent" value="consent_tick" required>'+
          '<label style="margin-left:1em" for="consent">I confirm that I have read the debrief, and understand who I can contact if I have any concerns.</label></p>',
  button_label: 'Next',
  list_questions: true
};

let final_survey = {
  type: 'survey-html-form',
  html:'<style id="jspsych-survey-likert-css">'+
        ".jspsych-survey-likert-statement { display:block; font-size:1.5em; padding-top: 40px; margin-bottom:1.75rem; }"+
        ".jspsych-survey-likert-opts { list-style:none; width:900px; margin:auto; padding:0 0 35px; display:block; font-size:1.05em; line-height:1.1em; }"+
        ".jspsych-survey-likert-opt-label { line-height: 1.1em; color: #444; }"+
        ".jspsych-survey-likert-opts:before { content: ''; position:relative; top:11px; /*left:9.5%;*/ display:block; background-color:#efefef; height:4px; width:100%; }"+
        ".jspsych-survey-likert-opts:last-of-type { border-bottom: 0; }"+
        ".jspsych-survey-likert-opts li { display:inline-block; /*width:19%;*/ text-align:center; vertical-align: top; }"+
        ".jspsych-survey-likert-opts li input[type=radio] { display:block; position:relative; top:0; left:50%; margin-left:-6px; }"+
      '</style>'+
      '<div style="max-width:1440px; margin-left:1em; margin-right:1em">'+
        '<div id="jspsych-survey-likert-preamble" class="jspsych-survey-likert-preamble" style="font-size:1.5em;color:#D17373;margin-top:3em">'+
          '<em>Please answer as honestly as possible - this survey has no bearing on your payment or possible bonus!</em>'+
        '</div>'+
        '<div class="jspsych-survey-likert-statement" style="font-size:1.25em;margin-top:1.5em">How did you find the experiment overall?</div>'+
          '<ul class="jspsych-survey-likert-opts" data-name="overall" data-radio-group="enjoy">'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="enjoy" value="0" required>Not at all enjoyable</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="enjoy" value="1" required>Slightly enjoyable</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="enjoy" value="2" required>Moderately enjoyable</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="enjoy" value="3" required>Very enjoyable</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="enjoy" value="4" required>Extremely enjoyable</label></li>'+
          '</ul>'+
        '<div class="jspsych-survey-likert-statement" style="font-size:1.25em;">How well were you able to concentrate during the experiment?</div>'+
          '<ul class="jspsych-survey-likert-opts" data-name="concentration" data-radio-group="concentrate">'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="concentrate" value="0" required>Not at all well</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="concentrate" value="1" required>Slightly well</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="concentrate" value="2" required>Moderately well</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="concentrate" value="3" required>Very well</label></li>'+
            '<li style="width:20%"><label class="jspsych-survey-likert-opt-label"><input type="radio" name="concentrate" value="4" required>Extremely well</label></li>'+
          '</ul>'+
        '<div>'+
          '<p style="font-size:1.25em;margin-top:1.5em;margin-bottom:2rem">Did you experience any technical issues during the experiment (e.g. images/files not loading, freezing)?</p>'+
          '<p style="font-size:1.05em;">'+
            '<input type="radio" id="technical_yes" name="technical" value="1" required>'+
              '<label style="margin-left:0.5rem;margin-right:2em;color: #444;" for="technical_yes">Yes (please specify)</label>'+
            '<input style="margin-left:1rem" type="radio" id="technical_no" name="technical" value="0" required>'+
              '<label style="margin-left:0.5rem;color: #444;" for="technical_no">No</label>'+              
          '</p>'+
            '<textarea style="margin-left:1rem;width:600px;height:5em;display:none" type="text" id="technical_text" name="technical_comments"></textarea>'+
        '</div>'+
        '<div>'+
          '<p style="font-size:1.25em;margin-top:2.5em;line-height:1.2">Did you experience any issues with the layout or design of the experiment (e.g. pages too large for screen, text too large/small, overlapping lines)</p>'+
          '<p style="font-size:1.05em">'+
            '<input type="radio" id="layout_yes" name="layout" value="1" required>'+
              '<label style="margin-left:0.5rem;margin-right:2em;color: #444;" for="layout_yes">Yes (please specify)</label>'+
            '<input style="margin-left:1rem" type="radio" id="layout_no" name="layout" value="0" required>'+
              '<label style="margin-left:0.5rem;color: #444;" for="layout_no">No</label>'+              
          '</p>'+
            '<textarea style="margin-left:1rem;width:600px;height:5em;display:none" type="text" id="layout_text" name="layout_comments"></textarea>'+
        '</div>'+
        '<div>'+
          '<p style="font-size:1.25em;margin-top:2.5em;line-height:1.2">Do you have any other comments on how we can improve the experiment?</p>'+
          '<p style="font-size:1.05em">'+
            '<input type="radio" id="other_comments_yes" name="other" value="1" required>'+
              '<label style="margin-left:0.5rem;margin-right:2em;color: #444;" for="other_comments_yes">Yes (please specify)</label>'+
            '<input style="margin-left:1rem;margin-bottom:1rem" type="radio" id="other_comments_no" name="other" value="0" required>'+
              '<label style="margin-left:0.5rem;color: #444;" for="other_comments_no">No</label>'+              
          '</p>'+
            '<textarea style="margin-left:1rem;margin-bottom:2rem;width:600px;height:5em;display:none" type="text" id="other_comments_text" name="other_comments"></textarea>'+
        '</div>'+
      '</div>',
  comment_text_hidden: true,
  comment_radio_pairs: [
    {radio_yes_id: 'technical_yes', radio_no_id: 'technical_no', textarea_id: 'technical_text', required_message: 'Please specify what technical issues you had.'},
    {radio_yes_id: 'layout_yes', radio_no_id: 'layout_no', textarea_id: 'layout_text', required_message: 'Please specify what layout issues you had.'},
    {radio_yes_id: 'other_comments_yes', radio_no_id: 'other_comments_no', textarea_id: 'other_comments_text', required_message: 'Please specify what other thoughts you have.'}
  ],
  list_questions: true,
  on_finish: function(data) {
    let feedback = jsPsych.data.get().last(1).values()[0].responses;
    let enjoyment = feedback.substring(0,feedback.indexOf("concentrate")).match(/[0-4]/g);
    data.enjoyment = parseInt(enjoyment);
    let concentration = feedback.substring(feedback.indexOf("concentrate"),feedback.indexOf("technical")).match(/[0-4]/g);
    data.concentration = parseInt(concentration);
    let technical = feedback.substring(feedback.indexOf("technical"),feedback.indexOf("technical_comments")).match(/[0-1]/g);
    data.technical = parseInt(technical);
    if (technical==1) {
      let technical_comments = feedback.substring(feedback.indexOf("technical_comments"),feedback.indexOf("layout")).replace(/[\"\{]/g, '').replace("technical_comments:",'').replace(/,$/,"");
      data.technical_comments = technical_comments
    }
    let layout = feedback.substring(feedback.indexOf("layout"),feedback.indexOf("layout_comments")).match(/[0-1]/g);
    data.layout = parseInt(layout);
    if (layout==1) {
      let layout_comments = feedback.substring(feedback.indexOf("layout_comments"),feedback.indexOf("other")).replace(/[\"\{]/g, '').replace("layout_comments:",'').replace(/,$/,"");
      data.layout_comments = layout_comments
    }
    let other = feedback.substring(feedback.indexOf("other"),feedback.indexOf("other_comments")).match(/[0-1]/g);
    data.other = parseInt(other);
    if (other==1) {
      let other_comments = feedback.substring(feedback.indexOf("other_comments"),feedback.lastIndexOf("}")).replace(/[\"\{]/g, '').replace("other_comments:",'').replace(/,$/,"");
      data.other_comments = other_comments
    }
  }
};

let redirect = {
  type: 'html-button-response',
  stimulus: '<div style="font-size:1.5em;color:#6B6D8C;line-height:1">'+
              '<p><h2>Well done! You have completed the experiment. Thank you for taking part!</p></h2>'+
            '</div>'+
            '<div style="font-size:1.5em;color:#6B6D8C;max-width:1440px;line-height:1.25">'+
              '<p>You will now be re-directed to Prolific to record that you have completed the study, and we will approve your submission as soon as we can.</p>'+
              '<p>Press <em>Finish</em> to log your results and proceed to Prolific.</p>'+
            '</div>',
  choices: ['Finish']
};

timeline.push(finish, debrief, final_survey, redirect);


/* start the experiment */

/*
 
jatos.onLoad(function () {
  jsPsych.init({
    timeline: timeline,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, jatos.endStudy); 
    }
  });
});

*/

jatos.onLoad(function () {
  prolific_id = jatos.urlQueryParameters.PROLIFIC_PID;
  study_id = jatos.urlQueryParameters.STUDY_ID;
  session_id = jatos.urlQueryParameters.SESSION_ID;
  jsPsych.data.addProperties({prolific_id: prolific_id, study_id: study_id, session_id: session_id});
  jsPsych.init({
    timeline: timeline,
    on_finish: function(){
      window.onbeforeunload = null;
      let trialsJson = jsPsych.data.get().json();
      jatos.appendResultData(trialsJson, jatos.endStudyAjax)
        .done(() => {
          window.location.href = jatos.batchJsonInput.completion_link;
      });
    }
  });
});